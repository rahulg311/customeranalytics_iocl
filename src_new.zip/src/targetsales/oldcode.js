"use client";
import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  ReferenceLine,
} from "recharts";
import {
  TrendingUp,
  Target,
  BarChart3,
  Calendar,
  ChevronDown,
  LogOut,
  Layers,
  X,
  Mail,
  Upload,
  FileSpreadsheet,
  Send,
} from "lucide-react";
import { Link } from "react-router-dom";
import * as XLSX from "xlsx";

import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import ic_logo from "../assets/images/ic_logo.gif";
import SectorReportTable from "./SectorReportTable";
import ZonePivotTable from "./ZonePivotTable";
import withSessionContext from "../HOC/withSessionContext";
import Header from "../components/header";
import Footer from "../components/footer";
import OverallSectorReportTable from "./OverallSectorReportTable";
import SelectBox from "../components/SelectBox";
import { hostUrl } from "../utils/constant";
// Import all necessary types

// Import all custom components

function UplodeTargetSale(props) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedExcelData, setUploadedExcelData] = useState([]);
  const [excelHeaders, setExcelHeaders] = useState([]);
  const [uploadFileName, setUploadFileName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef(null);
  const [duplicateGrades, setDuplicateGrades] = useState(new Set());
  const [invalidValueRows, setInvalidValueRows] = useState(new Set());

  const months = [
    { id: 4, label: "April", value: "04" },
    { id: 5, label: "May", value: "05" },
    { id: 6, label: "June", value: "06" },
    { id: 7, label: "July", value: "07" },
    { id: 8, label: "August", value: "08" },
    { id: 9, label: "September", value: "09" },
    { id: 10, label: "October", value: "10" },
    { id: 11, label: "November", value: "11" },
    { id: 12, label: "December", value: "12" },
    { id: 1, label: "January", value: "01" },
    { id: 2, label: "February", value: "02" },
    { id: 3, label: "March", value: "03" },
  ];
  const currentDate = new Date();
  const currentYear = new Date().getFullYear();
  const currentMonth = String(currentDate.getMonth() + 1).padStart(2, "0");

  const year = [
    { id: 1, label: "2020", value: "2020" },
    { id: 2, label: "2021", value: "2021" },
    { id: 3, label: "2022", value: "2022" },
    { id: 4, label: "2023", value: "2023" },
    { id: 5, label: "2024", value: "2024" },
    { id: 6, label: "2025", value: "2025" },
    { id: 7, label: "2026", value: "2026" },
    { id: 8, label: "2027", value: "2027" },
    { id: 9, label: "2028", value: "2028" },
    { id: 10, label: "2029", value: "2029" },
    { id: 11, label: "2030", value: "2030" },
    { id: 12, label: "2031", value: "2031" },
  ];

  const targetType = [
    { id: 1, label: "Polymer Monthly Target", value: "1" },
    { id: 2, label: "Recyclate Monthly Target", value: "2" },
  ]
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [salesTargetType, setSalesTargetType] = useState(targetType[0].value);
  const [selectedYear, setSelectedYear] = useState(String(currentYear));

  // Validate Excel Data
  const validateExcelData = (data, headers) => {
    const gradeIndex = 0; // first column is "Grades"
    const gradeCount = {};
    const duplicates = new Set();
    const invalidRows = new Set();

    data.forEach((row, rowIdx) => {
      const grade = row[gradeIndex];

      // Check for duplicate grades
      if (grade !== undefined && grade !== "") {
        if (gradeCount[grade] !== undefined) {
          duplicates.add(gradeCount[grade]); // first occurrence
          duplicates.add(rowIdx); // current occurrence
        } else {
          gradeCount[grade] = rowIdx;
        }
      }

      // Check for non-numeric values
      for (let colIdx = 1; colIdx < headers.length; colIdx++) {
        const value = row[colIdx];
        if (value !== undefined && value !== "" && value !== null) {
          // Check if value is not a valid number
          if (typeof value !== "number" && isNaN(Number(value))) {
            invalidRows.add(rowIdx);
            break;
          }
        }
      }
    });

    setDuplicateGrades(duplicates);
    setInvalidValueRows(invalidRows);
  };

  // Excel Upload Handlers
  const handleFileUpload = (e) => {
    if (!selectedMonth) {
      toast.warning("Please select a month");
      return;
    }
    if (!selectedYear) {
      toast.warning("Please select a year");
      return;
    }

    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target.result;
        const workbook = XLSX.read(bstr, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        console.log(jsonData, "jsonData");

        if (jsonData.length > 0) {
          const headers = jsonData[0];
          const rows = jsonData
            .slice(1)
            .filter((row) =>
              row.some((cell) => cell !== undefined && cell !== ""),
            );

          setExcelHeaders(headers);
          setUploadedExcelData(rows);
          setUploadFileName(file.name);
          setActiveTab("uploadExcel");

          // Validate the data
          validateExcelData(rows, headers);

          toast.success(`Loaded ${rows.length} rows from ${file.name}`);
        } else {
          toast.error("No data found in the Excel file");
        }
      } catch (error) {
        console.error("Error parsing Excel:", error);
        toast.error("Error parsing Excel file");
      } finally {
        setIsUploading(false);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDownLoadTemplate = () => {
    const link = document.createElement("a");
    // link.href = "/Month_Target.xlsx";
    link.href = "/customeranalytics/Month_Target.xlsx";
    console.log(link.href, "link.href");
    link.download = "Month_Target.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleClearUpload = () => {
    setUploadedExcelData([]);
    setExcelHeaders([]);
    setUploadFileName("");
    setDuplicateGrades(new Set());
    setInvalidValueRows(new Set());
    setActiveTab("overview");
  };

  const handleSubmitExcelData = async () => {
    console.log('ser', salesTargetType, typeof salesTargetType)
    // return;
    if (uploadedExcelData.length === 0) {
      toast.error("No data to submit");
      return;
    }

    const result = uploadedExcelData.flatMap((row) => {
      const grade = row[0];

      return excelHeaders.slice(1).map((zone, index) => ({
        grades: grade,
        zone: zone,
        target: Number(row[index + 1]) || 0,
        month_YEAR: `${selectedMonth}${selectedYear}`,
      }));
    });

    // console.log(result, "result");

    if (result.length === 0) {
      toast.error("Processed data is empty");
      return;
    }

    const data = {
      monYear: result[0].month_YEAR,
      lineItems: result,
    };

    // console.log("final payload", data);

    setIsSubmitting(true);
    // const toastId = toast.loading("Submitting data to API...");
    const apiUrl = salesTargetType == 1 ? 
    `${hostUrl}/TargetSales/UploadMonthlyTargets` :
    `${hostUrl}/TargetSales/UploadRecyclateMonthlyTargets`
    try {
      const response = await fetch(
        apiUrl,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        },
      );

      const result = await response.json();
      // console.log("api Response ---", response, result);

      // console.log("right 1", response.status);

      if (result.status === false) {
        toast.error(`Server Error: ${result.message}`);
        return;
      }
      toast.success("Data submitted successfully!");
      console.log("right 3", result.status);

      // toast.update(toastId, {
      //   render: "Data submitted successfully!",
      //   type: "success",
      //   isLoading: false,
      //   autoClose: 3000,
      // });

      setSelectedMonth("");
      setSelectedYear("");
      handleClearUpload();
    } catch (error) {
      console.error("Submit error:", error);
      toast.error(`Failed to submit: ${error.message}`);
      // toast.update(toastId, {
      //   render: `Failed to submit: ${error.message}`,
      //   type: "error",
      //   isLoading: false,
      //   autoClose: 5000,
      // });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Check if form is valid for submission
  const isFormValid = useMemo(() => {
    return (
      uploadedExcelData.length > 0 &&
      duplicateGrades.size === 0 &&
      invalidValueRows.size === 0
    );
  }, [uploadedExcelData, duplicateGrades, invalidValueRows]);

  // const chartData = [];

  const getColumnTotal = (colIdx) => {
    return (
      uploadedExcelData
        // .slice(0, -1)
        .reduce((sum, row) => {
          const val = Number(row[colIdx]);
          return sum + (isNaN(val) ? 0 : val);
        }, 0)
    );
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      {/* <Toaster richColors position="top-right" /> */}
      <Header />
      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-6">
        {/* Header */}

        {/* Month and Year Selectors */}
        <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
            <div className="flex flex-wrap items-end gap-4">
              <div className="w-72">
                <SelectBox
                  label="Select Sales Target Type"
                  value={salesTargetType}
                  onChange={setSalesTargetType}
                  options={targetType}
                />
              </div>
              <div className="w-72">
                <SelectBox
                  label="Select Month"
                  value={selectedMonth}
                  onChange={setSelectedMonth}
                  options={months}
                />
              </div>
              <div className="w-72">
                <SelectBox
                  label="Select Year"
                  value={selectedYear}
                  onChange={setSelectedYear}
                  options={year}
                />
              </div>
              <div>
              <button
                className="flex items-center gap-2 px-5 py-2.5 font-semibold bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition shadow-sm"
                onClick={handleDownLoadTemplate}
              >
                <FileSpreadsheet size={18} />
                Download Template
              </button>
            </div>
              <div className="pb-1">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="excel-upload-direct"
                />
                <label
                  htmlFor="excel-upload-direct"
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium cursor-pointer transition-all ${
                    activeTab === "uploadExcel"
                      ? "bg-blue-600 text-white shadow-md"
                      : "bg-green-600 text-white hover:bg-green-700"
                  }`}
                >
                  <Upload className="w-4 h-4" />
                  {isUploading ? "Uploading..." : "Upload Excel"}
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Conditional Content Area */}
        {activeTab === "uploadExcel" ? (
          <div
            className="bg-white rounded-xl p-6 shadow-xl border"
            style={{ marginBottom: "80px" }}
          >
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="w-7 h-7 text-green-600" />
                <div>
                  <h2 className="text-xl font-bold text-gray-500">
                    {uploadFileName}
                  </h2>
                  {/* <p className="text-sm text-gray-500">{uploadFileName}</p> */}
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleClearUpload}
                  className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-all"
                >
                  <X className="w-4 h-4" /> Cancel
                </button>

                <button
                  onClick={handleSubmitExcelData}
                  disabled={isSubmitting || !isFormValid}
                  className={`flex items-center gap-2 px-6 py-2 rounded-lg transition-all ${
                    isFormValid
                      ? "bg-green-600 text-white hover:bg-green-700"
                      : "bg-gray-400 text-gray-200 cursor-not-allowed"
                  }`}
                  title={
                    !isFormValid
                      ? "Please fix all validation errors before submitting"
                      : ""
                  }
                >
                  <Send className="w-5 h-5" />
                  {isSubmitting ? "Submitting..." : "Submit"}
                </button>
              </div>
            </div>

            <div className="mb-4 flex items-center gap-4">
              <p className="text-sm text-gray-600">
                <strong>{uploadedExcelData.length}</strong> rows loaded from
                Excel file
              </p>
              {/* Validation Error Summary */}
              {(duplicateGrades.size > 0 || invalidValueRows.size > 0) && (
                <div className="flex items-center gap-3">
                  {duplicateGrades.size > 0 && (
                    <span className="text-red-600 text-xs font-medium bg-red-50 px-2 py-1 rounded">
                      Duplicate Grades: {duplicateGrades.size}
                    </span>
                  )}
                  {invalidValueRows.size > 0 && (
                    <span className="text-orange-600 text-xs font-medium bg-orange-50 px-2 py-1 rounded">
                      Invalid Values: {invalidValueRows.size}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Data Table */}
            <div className="overflow-x-auto">
              <table className="border-collapse w-full text-sm">
                <thead>
                  <tr className="bg-slate-700 text-white">
                    {excelHeaders.map((header, idx) => (
                      <th
                        key={idx}
                        className="p-3 border border-slate-400 text-center font-semibold"
                      >
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                {/* <tbody>
                  .slice(0, -1)
                  {uploadedExcelData.map((row, rowIdx) => {
                    const isDuplicate = duplicateGrades.has(rowIdx);
                    const hasInvalidValue = invalidValueRows.has(rowIdx);

                    const rowBgColor =
                      isDuplicate || hasInvalidValue
                        ? "bg-red-100"
                        : rowIdx % 2 === 0
                          ? "bg-white"
                          : "bg-gray-50";

                    return (
                      <tr key={rowIdx} className={rowBgColor}>
                        {excelHeaders.map((_, colIdx) => {
                          const cellValue = row[colIdx];

                          const isCellInvalid =
                            colIdx > 0 &&
                            cellValue !== undefined &&
                            cellValue !== "" &&
                            cellValue !== null &&
                            typeof cellValue !== "number" &&
                            isNaN(Number(cellValue));

                          return (
                            <td
                              key={colIdx}
                              className={`p-2 border border-slate-300 text-center ${
                                isCellInvalid
                                  ? "bg-orange-200 font-semibold text-orange-800"
                                  : ""
                              } ${
                                isDuplicate && colIdx === 0
                                  ? "font-semibold text-red-700"
                                  : ""
                              }`}
                            >
                              {colIdx === 0 ? (
                                <span className="font-medium text-gray-700">
                                  {cellValue}
                                </span>
                              ) : (
                                <input
                                  type="number"
                                  value={cellValue ?? ""}
                                  onChange={(e) => {
                                    const val = e.target.value;

                                    setUploadedExcelData((prev) => {
                                      const newData = [...prev];
                                      const newRow = [...newData[rowIdx]];
                                      newRow[colIdx] =
                                        val === "" ? "" : Number(val);
                                      newData[rowIdx] = newRow;

                                      // return newData;
                                    });
                                  }}
                                  className="w-full text-center"
                                />
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody> */}

                <tbody>
                  {uploadedExcelData.map((row, rowIdx) => (
                    <tr key={rowIdx}>
                      {excelHeaders.map((_, colIdx) => (
                        <td key={colIdx} className="p-2 border text-center">
                          {/* First column TEXT */}
                          {colIdx === 0 ? (
                            <span>{row[colIdx]}</span>
                          ) : (
                            <input
                              type="number"
                              value={row[colIdx] ?? ""}
                              onChange={(e) => {
                                const val = e.target.value;

                                setUploadedExcelData((prev) => {
                                  const newData = [...prev];
                                  const newRow = [...newData[rowIdx]];

                                  newRow[colIdx] =
                                    val === "" ? "" : Number(val);

                                  newData[rowIdx] = newRow;

                                  return newData;
                                });
                              }}
                              className="w-full text-center"
                            />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}

                  <tr className="bg-yellow-100 font-bold">
                    {excelHeaders.map((header, colIdx) => (
                      <td key={colIdx} className="p-2 border text-center">
                        {colIdx === 0 ? "Total" : getColumnTotal(colIdx)}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : null}

        {/* Footer */}
      </div>
      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
}
export default withSessionContext(UplodeTargetSale);
