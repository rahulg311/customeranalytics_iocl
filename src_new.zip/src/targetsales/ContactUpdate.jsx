import React, {useState, useEffect, useMemo, useCallback} from 'react';
import {AgGridReact} from 'ag-grid-react';
import Header from '../components/header';
import Footer from '../components/footer';
import {ToastContainer, toast} from 'react-toastify';
import {hostUrl} from '../utils/constant';
import withSessionContext from '../HOC/withSessionContext';

const ContactUpdate = (props) => {
  const auTOptionsS = [
    {id: '1', label: 'Actual User', val: 'Actual User'},
    {id: '2', label: 'Traders', val: 'Traders'}
  ];

  const appSubTypeOptionsS = [
    {id: '1', label: 'Regular', val: 'Regular'},
    {id: '2', label: 'Monthly', val: 'Monthly'}
  ];
  const statusoption = [
    {id: '1', label: 'Active', val: 'Active'},
    {id: '2', label: 'Deactive', val: 'Deactive'}
  ];

  const months = [
    {id: 1, label: 'April', value: '01'},
    {id: 2, label: 'May', value: '02'},
    {id: 3, label: 'June', value: '03'},
    {id: 4, label: 'July', value: '04'},
    {id: 5, label: 'August', value: '05'},
    {id: 6, label: 'September', value: '06'},
    {id: 7, label: 'October', value: '07'},
    {id: 8, label: 'November', value: '08'},
    {id: 9, label: 'December', value: '09'},
    {id: 10, label: 'January', value: '10'},
    {id: 11, label: 'February', value: '11'},
    {id: 12, label: 'March', value: '12'}
  ];

const currentMonth = new Date().getMonth() + 1;


const currentFYMonth =
  currentMonth >= 4
    ? currentMonth - 3
    : currentMonth + 9;

// Current month se March (value 12) tak
const validFromMonths = months.filter(
  month => Number(month.value) >= currentFYMonth )

  
  let UserNamelogin = props.sessionContext?.username ?? "";
  const [Financialyear, setFinancialyear] = useState('');
  const [soldToParty, setSoldToParty] = useState('');
  const [validFromMonth, setvalidFromMonth] = useState("");
  const [ValidToMonth, setValidToMonth] = useState('');
  const [zone, setZone] = useState('');
  const [ZoneName, setZoneName] = useState('');

  const [fieldOfficer, setFieldOfficer] = useState('');
  const [auT, setAuT] = useState('');
  const [appSubType, setAppSubType] = useState('');
  const [AppSubType1, setAppSubType1] = useState('');

  const [appType, setAppType] = useState('');
  const [status, setStatus] = useState('');

  const [grade, setGrade] = useState('');
  const [Month, setMonth] = useState('');
  const [quantity, setQuantity] = useState('');
  const [appTypeNameCode, setAppTypeNameCode] = useState('');

  // Required API Response State
  const [PERSONAL_NO, setPERSONAL_NO] = useState('');
  const [CustomerName, setCustomerName] = useState('');
  const [Parent_Code, setParent_Code] = useState('');
  const [Parent_Description, setParent_Description] = useState('');

  // Dropdown Options
  const [SolidTopartyOptions, setSolidTopartyOptions] = useState([]);
  const [FieldOfficerOptions, setFieldOfficerOptions] = useState([]);
  const [zoneOptions, setZoneOptions] = useState([]);
  const [auTOptions] = useState(auTOptionsS);
  const [appSubTypeOptions] = useState(appSubTypeOptionsS);
  const [gradeOptions, setGradeOptions] = useState([]);
  const [ApptypeOptions, setApptypeOptions] = useState([]);
  const [statusoptions, setstatusoptions] = useState(statusoption);

  // UI / Grid State
  
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // Financial Year Setup
  const today = new Date();
  const currentYear = today.getFullYear();
  const month = today.getMonth();
  const financialYearStart = month >= 3 ? currentYear : currentYear - 1;

  const currentFinancialYear = `${financialYearStart}${String(
    financialYearStart + 1
  ).slice(-2)}`;

  const nextFinancialYear = `${financialYearStart + 1}${String(
    financialYearStart + 2
  ).slice(-2)}`;

  const FinancialYearOptions = [
    {key: currentFinancialYear, value: currentFinancialYear},
    {key: nextFinancialYear, value: nextFinancialYear}
  ];

  const [FinancialyearOptions] = useState(FinancialYearOptions);

  // Fetch Dropdown Data
  const fetchDropdownData = useCallback(async () => {
     setGridLoading(true);
    try {
      
      const results = await Promise.allSettled([
        fetch(`${hostUrl}/Master/GetAllSoldToParty`),
        fetch(`${hostUrl}/Master/GetAllFieldOfficer`),
        fetch(`${hostUrl}/Master/GetAllZoneCode`),
        fetch(`${hostUrl}/Master/GetAllGradeTargetMaster`),
        fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({fy: currentFinancialYear})
        })
      ]);

      const [soldtoparty, FieldOfficer, zoneRes, gradeRes, apptype] = results;

      if (soldtoparty.status === 'fulfilled' && soldtoparty.value.ok) {
        const data = await soldtoparty.value.json();
        setSolidTopartyOptions(data);
      }

      if (FieldOfficer.status === 'fulfilled' && FieldOfficer.value.ok) {
        const data = await FieldOfficer.value.json();
        setFieldOfficerOptions(
          data.map((item) => ({
            id: item.personaL_NO,
            label: item.name,
            personaL_NO: item.personaL_NO,
            name: item.name
          }))
        );
      }

      if (zoneRes.status === 'fulfilled' && zoneRes.value.ok) {
        const data = await zoneRes.value.json();
        setZoneOptions(data);
      }

      if (gradeRes.status === 'fulfilled' && gradeRes.value.ok) {
        const data = await gradeRes.value.json();
        setGradeOptions(data);
      }

      if (apptype.status === 'fulfilled' && apptype.value.ok) {
        const data = await apptype.value.json();
        setApptypeOptions(data);
      }
    } catch (error) {
      console.error('Error fetching dropdown options:', error);
    }finally {
      setGridLoading(false);
    }

  }, [currentFinancialYear]);

  // Fetch Grid Data
  const fetchContractData = useCallback(async () => {
    // setGridLoading(true);
    try {
      const response = await fetch(`${hostUrl}/TargetSales/GetAllAppFY`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          year: 202728,
          month: '0'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      }
    } catch (error) {
      console.error('GET API Error:', error);
    } finally {
      // setGridLoading(false);
    }
  }, [currentFinancialYear]);

  useEffect(() => {
    fetchDropdownData();
    fetchContractData();
  }, [fetchDropdownData, fetchContractData]);

  // Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isUpdating = editIndex !== null;

    const addPayload = {
      year: Financialyear || '',
      month: Month || '',

      sold_To_Party: soldToParty || '',
      dca_Account: '', // state nahi hai
      dca_Name: '', // state nahi hai

      valid_From_Mon: validFromMonth || '',
      valid_To_Mon: ValidToMonth || '',

      zo_Code: zone,
      zo_Name: ZoneName || '',

      field_Officer: fieldOfficer || '',
      personal_NO: PERSONAL_NO || '',

      sales_Group: '', // state nahi hai
      sales_Group_TEXT: '', // state nahi hai

      customer_Name: CustomerName || '',

      au_T: auT || '',

      app_Type: appType || '',
      app_code: appTypeNameCode,

      app_Sub_Type: appSubType || '',
      app_Sub_Type1: AppSubType1, // state nahi hai

      grade: grade || '',

      parent_Code: Parent_Code || '',
      parent_Description: Parent_Description || '',

      status: status || '',
      quantity: quantity || '',
       created_By: UserNamelogin,
    };

  

    const updatePayload = {
      year: Financialyear,
      Month: Number(Month),
      sold_To_Party: soldToParty,
      grade: grade,
      customer_Name: CustomerName,
      status: status,
      quantity: quantity,
        updated_By: UserNamelogin
    };

    //     console.log("----- addPayload -----");
    // Object.entries(addPayload).forEach(([key, value]) => {
    //   console.log(`${key}:`, value);
    // });

    // console.log("----- updatePayload -----");
    // Object.entries(updatePayload).forEach(([key, value]) => {
    //   console.log(`${key}:`, value);
    // });

    // return

    const payload = isUpdating ? updatePayload : addPayload;
    const apiUrl = isUpdating
      ? `${hostUrl}/TargetSales/UpdateAppFY`
      : `${hostUrl}/TargetSales/AddAppFY`;

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      console.log('result:', result);
      // console.log('Result:', result);
      // console.log('Message:', result?.message);

      if (response.ok) {
        toast.success(result?.message);

        handleReset();
        fetchContractData();
      } else {
        toast.warning(
          result?.message ||
            `Failed to ${isUpdating ? 'update' : 'save'} data. Status: ${response.status}`
        );
      }
    } catch (error) {
      toast.warning('Network or API Server Error!');
      console.error('API Error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Format Date for <input type="date" />
  // const formatDateForInput = (dateStr) => {
  //   if (!dateStr) return '';
  //   if (dateStr.includes('T')) return dateStr.split('T')[0];
  //   return dateStr;
  // };

  // Edit Handler
  console.log('setStatus', status);
  const handleEdit = (data, index) => {
    console.log(data, 'data.zo_Code');
    setFinancialyear(data.year || '');
    setSoldToParty(data?.sold_To_Party || '');
    setCustomerName(data.customer_Name || '');
    setvalidFromMonth(data.valid_From_Mon);
    setValidToMonth(data.valid_To_Mon);
    setZone(data.zo_Code || '');
    setZoneName(data.zo_Name ?? '');
    setFieldOfficer(data.field_Officer || '');
    setPERSONAL_NO(data.personaL_NO || '');
    setAuT(data.aU_T || '');
    setAppSubType(data.apP_Sub_Type || '');
    setAppSubType1(data.app_Sub_Type1 || '');
    setAppType(data.apP_Type || '');
    setAppTypeNameCode(data.app_code || '');
    setGrade(data.parent_Description || '');
    setParent_Code(data.parent_Code || '');
    setParent_Description(data.parent_Description || '');
    setMonth(data.month || '');
    setQuantity(data.quantity || '');
    setStatus(data.status);

    setEditIndex(index);
    window.scrollTo({top: 0, behavior: 'smooth'});
  };

  // Reset Handler
  const handleReset = () => {
    setFinancialyear('');
    setSoldToParty('');
    setCustomerName('');
    setvalidFromMonth('');
    setValidToMonth('');
    setZone('');

    setFieldOfficer('');
    setPERSONAL_NO('');
    setAuT('');
    setAppSubType('');
    setAppSubType1('');
    setAppType('');
    setGrade('');
    setParent_Code('');
    setParent_Description('');
    setMonth('');
    setQuantity('');
    setStatus('');
    setEditIndex(null);
  };

  // Grid Columns
  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Financial year',
        field: 'year',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Sold To Party',
        field: 'sold_To_Party',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Customer',
        field: 'customer_Name',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Valid From',
        field: 'valid_From_Mon',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Valid To',
        field: 'valid_To_Mon',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Zone',
        field: 'zo_Name',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Field Officer',
        field: 'field_Officer',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Personal No',
        field: 'personaL_NO',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'AU/T',
        field: 'aU_T',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'APP Sub Type',
        field: 'apP_Sub_Type',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Grade',
        field: 'grade',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Parent Code',
        field: 'parent_Code',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Parent Description',
        field: 'parent_Description',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Month',
        field: 'month',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Quantity',
        field: 'quantity',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Status',
        field: 'status',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Action',
        width: 120,
        cellRenderer: (params) => (
          <div className="flex gap-2 mt-2">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
            >
              Edit
            </button>
          </div>
        )
      }
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Contract Update" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* FORM */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null
                  ? 'Edit Contract Update'
                  : 'Create Contract Update'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                {/* Financial Year */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Financial year <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={Financialyear}
                    onChange={(e) => setFinancialyear(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Financial year</option>
                    {FinancialyearOptions.map((item) => (
                      <option key={item.key} value={item.key}>
                        {item.value}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Sold To Party */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Sold To Party <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={soldToParty}
                    onChange={(e) => {
                      const selectedCode = e.target.value;
                      setSoldToParty(selectedCode);
                      const selectedItem = SolidTopartyOptions.find(
                        (item) => item.customer_Code === selectedCode
                      );
                      setCustomerName(selectedItem?.cusT_NAME || '');
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Sold To Party</option>
                    {SolidTopartyOptions.map((item) => (
                      <option
                        key={item.id || item.customer_Code}
                        value={item.customer_Code}
                      >
                        {item.customer_Code}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Valid From */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Valid From <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={validFromMonth}
                    onChange={(e) => setvalidFromMonth(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Zone</option>
                    {validFromMonths.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Valid To */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Valid To <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={ValidToMonth}
                    onChange={(e) => setValidToMonth(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Zone</option>
                    {validFromMonths.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Zone */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Zone code <span className="text-red-500">*</span>
                  </label>
                

                  <select
                    value={zone}
                    onChange={(e) => {
                      const value = e.target.value;

                      setZone(value);

                      const selectedZone = zoneOptions.find(
                        (item) => String(item.zo_Code) === String(value)
                      );

                      setZoneName(selectedZone?.zo_Name || '');
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Zone</option>

                    {zoneOptions.map((item) => (
                      <option key={item.zo_Code} value={item.zo_Code}>
                        {`${item.zo_Code} - ${item.zo_Name}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Field Officer */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Field Officer <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={fieldOfficer}
                    onChange={(e) => {
                      const selectedName = e.target.value;
                      setFieldOfficer(selectedName);
                      const selectedItem = FieldOfficerOptions.find(
                        (item) => item.name === selectedName
                      );
                      setPERSONAL_NO(selectedItem?.personaL_NO || '');
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Field Officer</option>
                    {FieldOfficerOptions.map((item) => (
                      <option
                        key={item.id || item.personaL_NO}
                        value={item.name}
                      >
                            {`${item.personaL_NO} - ${item.label}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* AU/T */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    AU/T <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={auT}
                    onChange={(e) => setAuT(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select AU/T</option>
                    {auTOptions.map((item) => (
                      <option key={item.id} value={item.val}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* APP Sub Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    APP Sub Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={appSubType}
                    // onChange={(e) => setAppSubType(e.target.value)}
                    onChange={(e) => {
                      const selectedName = e.target.value;
                      setAppSubType(e.target.value);
                      const selectedItem = appSubTypeOptions.find(
                        (item) => item.val === selectedName
                      );
                      console.log('selectedItem', selectedItem);
                      setAppSubType1(selectedItem?.id || '');
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select APP Sub Type</option>
                    {appSubTypeOptions.map((item) => (
                      <option key={item.id} value={item.val}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* APP Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    APP Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={appType}
                    // onChange={(e) => setAppType(e.target.value)}
                    onChange={(e) => {
                      const value = e.target.value;

                      setAppType(value);

                      const selectedAppType = ApptypeOptions.find(
                        (item) => String(item.id) === String(value)
                      );

                      setAppTypeNameCode(selectedAppType?.appCode || '');
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select APP Type</option>
                    {ApptypeOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Grade */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={grade}
                    onChange={(e) => {
                      const selectedParentCode = e.target.value;
                      setGrade(selectedParentCode);
                      const selectedItem = gradeOptions.find(
                        (item) => item.parent_Description === selectedParentCode
                      );
                      setParent_Code(selectedItem?.parent_Code || '');
                      setParent_Description(
                        selectedItem?.parent_Description || ''
                      );
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Grade</option>
                    {gradeOptions.map((item) => (
                      <option
                        key={item.parent_Description}
                        value={item.parent_Description}
                      >
                        {` ${item.parent_Description}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quantity */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Quantity <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="Enter Quantity"
                    min="0"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* Month */}
                {/* <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Month <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={Month}
                    onChange={(e) => setMonth(e.target.value)}
                    placeholder="Enter Month details"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div> */}

                {/* Status */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Status <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Status</option>
                    {statusoptions.map((item) => (
                      <option key={item.id} value={item.val}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  disabled={loading}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded"
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded"
                >
                  {loading
                    ? 'Submitting...'
                    : editIndex !== null
                      ? 'Update'
                      : 'Submit'}
                </button>
              </div>
            </form>
          </div>

         
          <div className="bg-white rounded-lg shadow-lg mt-6 p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Contract List</h3>
            <div className="ag-theme-alpine w-full h-96">
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                loading={gridLoading}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default withSessionContext(ContactUpdate);
