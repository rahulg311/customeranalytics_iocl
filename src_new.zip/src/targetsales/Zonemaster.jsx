import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";

// AG Grid & Toastify CSS Imports
// import "ag-grid-community/styles/ag-grid.css";
// import "ag-grid-community/styles/ag-theme-alpine.css";
// import "react-toastify/dist/ReactToastify.css";

import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";
import { hostUrl } from "../utils/constant";

// Base API URL declared outside component to preserve callback reference stability
const API_BASE_URL = `${hostUrl}/Master`;

const ZoneMaster = () => {
  // Input States
  const [zoneCode, setZoneCode] = useState("");
  const [zoneName, setZoneName] = useState("");
  const [zoneShortName, setZoneShortName] = useState("");
  const [zoneValidFrom, setZoneValidFrom] = useState("");
  const [zoneValidTo, setZoneValidTo] = useState("");
  const [zoneSapName, setZoneSapName] = useState("");

  // Loading States
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);

  // Grid States
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // Safely format dates to ISO string without throwing RangeError on invalid input
  const safeToISOString = (dateStr) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? "" : date.toISOString();
  };

  // Extract YYYY-MM-DD format for date input components
  const formatDateForInput = (dateStr) => {
    if (!dateStr) return "";
    return dateStr.split("T")[0];
  };

  // 1. Fetch Zone Master Data
  const fetchZoneMasters = useCallback(async () => {
    setGridLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/ZoneMaster`);

      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error("Failed to fetch Zone Master list. Status:", response.status);
        toast.error("Failed to load grid data.");
      }
    } catch (error) {
      console.error("GET API Error:", error);
      toast.error("Network error while fetching grid data.");
    } finally {
      setGridLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchZoneMasters();
  }, [fetchZoneMasters]);

  // 2. Add / Update Form Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      ZoneCode: zoneCode,
      ZoneName: zoneName,
      ZoneShortName: zoneShortName,
      ZoneValidFrom: safeToISOString(zoneValidFrom),
      ZoneValidTo: safeToISOString(zoneValidTo),
      ZoneSapName: zoneSapName,
    };

    const isUpdating = editIndex !== null;
    const apiUrl = isUpdating
      ? `${API_BASE_URL}/UpdateZoneMaster`
      : `${API_BASE_URL}/AddZoneMaster`;

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(
          isUpdating
            ? "Zone Record Updated Successfully!"
            : "Zone Record Saved Successfully!"
        );
        handleReset();
        fetchZoneMasters();
      } else {
        toast.warning(
          `Failed to ${isUpdating ? "update" : "save"} data. Status: ${response.status}`
        );
      }
    } catch (error) {
      toast.error("Network or API Server Error!");
      console.error("API Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data, index) => {
    setZoneCode(data.zo_Code || "");
    setZoneName(data.zo_Name || "");
    setZoneShortName(data.zo_Short_Name  || "");
    setZoneValidFrom(
      formatDateForInput(data.zo_valid_from )
    );
    setZoneValidTo(
      formatDateForInput(data.zo_valid_to )
    );
    setZoneSapName(
      data.ZoneSapName || data.zo_SAP_Name || data.Zone_SapName || data.zone_SapName || ""
    );

    setEditIndex(index);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    setZoneCode("");
    setZoneName("");
    setZoneShortName("");
    setZoneValidFrom("");
    setZoneValidTo("");
    setZoneSapName("");
    setEditIndex(null);
  };

  // Formatter for displaying ISO dates clearly in AG Grid
  const dateCellFormatter = (params) => {
    if (!params.value) return "";
    const date = new Date(params.value);
    return isNaN(date.getTime()) ? params.value : date.toLocaleDateString();
  };

  const columnDefs = useMemo(
    () => [
      {
        headerName: "Zone Code",
        valueGetter: (params) =>
          params.data?.zo_Code || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Zone Name",
        valueGetter: (params) =>
          params.data?.zo_Name || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Short Name",
        valueGetter: (params) =>
          params.data?.zo_Short_Name  || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Valid From",
        valueGetter: (params) =>
          params.data?.zo_valid_from || "",
        valueFormatter: dateCellFormatter,
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Valid To",
        valueGetter: (params) =>
          params.data?.zo_valid_to|| "",
        valueFormatter: dateCellFormatter,
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "SAP Name",
        valueGetter: (params) =>
          params.data?.zo_SAP_Name || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Action",
        width: 120,
        cellRenderer: (params) => (
          <div className="flex items-center h-full">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node?.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
            >
              Edit
            </button>
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Zone Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* CARD 1: FORM CARD */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null ? "Edit Zone Master" : "Create Zone Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {/* Zone Code (Disabled in Edit Mode) */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Zone Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={zoneCode}
                    disabled={editIndex !== null}
                    onChange={(e) => setZoneCode(e.target.value)}
                    placeholder="Enter Zone Code (e.g., ZN01)"
                    className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                      editIndex !== null ? "bg-gray-100 cursor-not-allowed" : ""
                    }`}
                    required
                  />
                </div>

                {/* Zone Name */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Zone Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={zoneName}
                    onChange={(e) => setZoneName(e.target.value)}
                    placeholder="Enter Zone Name"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Zone Short Name */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Zone Short Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={zoneShortName}
                    onChange={(e) => setZoneShortName(e.target.value)}
                    placeholder="e.g., NZ, EZ"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Valid From */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Valid From <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={zoneValidFrom}
                    onChange={(e) => setZoneValidFrom(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Valid To */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Valid To <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={zoneValidTo}
                    onChange={(e) => setZoneValidTo(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* SAP Name */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    SAP Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={zoneSapName}
                    onChange={(e) => setZoneSapName(e.target.value)}
                    placeholder="Enter SAP Description Name"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 text-white px-5 py-2 rounded-md hover:bg-gray-600 transition-colors"
                  disabled={loading}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-300"
                >
                  {loading ? "Submitting..." : editIndex !== null ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* CARD 2: TABLE CARD */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">Zone Master List</h2>
              {gridLoading && (
                <span className="text-sm text-blue-600 font-medium">Loading Grid Data...</span>
              )}
            </div>

            <div className="ag-theme-alpine" style={{ height: "450px", width: "100%" }}>
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default ZoneMaster;