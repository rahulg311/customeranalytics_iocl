import React, { useEffect, useState, useMemo, useCallback } from "react";
import { Download, RotateCcw } from "lucide-react";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { toast, ToastContainer } from "react-toastify";
import { AgGridReact } from "ag-grid-react";
import Select, { components } from "react-select";
import { hostUrl } from '../utils/constant';

// // AG Grid CSS Imports (Inke bina grid first time blank/broken dikhti hai)
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';

const Tab2AppPerformanceStatus = () => {
    const today = new Date();
    const currentCalendarYear = today.getFullYear();
    const currentCalendarMonth = today.getMonth() + 1;

    // Financial Year Calculation
    const financialYearStart = currentCalendarMonth >= 4 ? currentCalendarYear : currentCalendarYear - 1;
    const currentFinancialYear = `${financialYearStart}${String(financialYearStart + 1).slice(-2)}`;
    const previousFinancialYear = `${financialYearStart - 1}${String(financialYearStart).slice(-2)}`;

    const typeOptions = [
        { key: previousFinancialYear, value: previousFinancialYear },
        { key: currentFinancialYear, value: currentFinancialYear },
    ];

    const [loading, setLoading] = useState(false);
    const [year, setYear] = useState(typeOptions[1].key);
    const [month, setMonth] = useState([]);
    const [threshold, setThreshold] = useState("75");
    const [categoryCode, setCategoryCode] = useState([]);
    const [categoryOptions, setCategoryOptions] = useState([]);
    const [fieldOfficerCode, setFieldOfficerCode] = useState([]);
    const [fieldOfficerNames, setFieldOfficerNames] = useState([]);
    const [fieldOfficerOptions, setFieldOfficerOptions] = useState([]);
    const [gridLoading, setGridLoading] = useState(false);
    const [rowData, setRowData] = useState([]);
    const [columnDefs, setColumnDefs] = useState([]);

    const months = [
        { id: 1, label: "April", value: "1" },
        { id: 2, label: "May", value: "2" },
        { id: 3, label: "June", value: "3" },
        { id: 4, label: "July", value: "4" },
        { id: 5, label: "August", value: "5" },
        { id: 6, label: "September", value: "6" },
        { id: 7, label: "October", value: "7" },
        { id: 8, label: "November", value: "8" },
        { id: 9, label: "December", value: "9" },
        { id: 10, label: "January", value: "10" },
        { id: 11, label: "February", value: "11" },
        { id: 12, label: "March", value: "12" },
    ];

    const currentFYMonth = currentCalendarMonth >= 4 ? currentCalendarMonth - 3 : currentCalendarMonth + 9;
    const validFromMonths = year === currentFinancialYear ? months.filter((item) => Number(item.value) <= currentFYMonth) : year === previousFinancialYear ? months : [];

    const selectionActions = [{ id: "__select_all__", label: "Select All" }];
    const monthOptions2 = [...validFromMonths];

    // Data Preparation Functions
    const prepareGridData = (apiData) => {
        if (!Array.isArray(apiData) || apiData.length === 0) {
            return { rows: [], zones: [] };
        }

        const zones = [...new Set(apiData.map((item) => item.zone_Name))];
        const appTypes = [...new Set(apiData.map((item) => item.app_Description))];

        const rows = [];

        appTypes.forEach((appType) => {
            const row = { appType };
            let rowNos = 0, rowSuccess = 0, rowDefault = 0;

            zones.forEach((zone) => {
                const zoneData = apiData.find(
                    (item) => item.app_Description === appType && item.zone_Name === zone
                );

                const nos = zoneData ? Number(zoneData.nos || 0) : 0;
                const success = zoneData ? Number(zoneData.apP_Success || 0) : 0;
                const defaultVal = zoneData ? Number(zoneData.apP_Default || 0) : 0;

                row[`nos_${zone}`] = nos;
                row[`success_${zone}`] = success;
                row[`default_${zone}`] = defaultVal;

                rowNos += nos;
                rowSuccess += success;
                rowDefault += defaultVal;
            });

            row.totalNos = rowNos;
            row.totalSuccess = rowSuccess;
            row.totalDefault = rowDefault;

            rows.push(row);
        });

        // Grand Total Row
        const totalRow = { appType: "Total" };
        let grandNos = 0, grandSuccess = 0, grandDefault = 0;

        zones.forEach((zone) => {
            const zoneItems = apiData.filter((item) => item.zone_Name === zone);
            const totalNosZone = zoneItems.reduce((sum, item) => sum + Number(item.nos || 0), 0);
            const totalSuccessZone = zoneItems.reduce((sum, item) => sum + Number(item.apP_Success || 0), 0);
            const totalDefaultZone = zoneItems.reduce((sum, item) => sum + Number(item.apP_Default || 0), 0);

            totalRow[`nos_${zone}`] = totalNosZone;
            totalRow[`success_${zone}`] = totalSuccessZone;
            totalRow[`default_${zone}`] = totalDefaultZone;

            grandNos += totalNosZone;
            grandSuccess += totalSuccessZone;
            grandDefault += totalDefaultZone;
        });

        totalRow.totalNos = grandNos;
        totalRow.totalSuccess = grandSuccess;
        totalRow.totalDefault = grandDefault;

        rows.push(totalRow);

        return { rows, zones };
    };

    const prepareGridColumns = (zones) => {
        const zoneColumns = zones.map((zone) => ({
            headerName: zone,
            children: [
                {
                    headerName: "Nos",
                    field: `nos_${zone}`,
                    type: "numericColumn",
                    valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                },
                {
                    headerName: "APP Success",
                    field: `success_${zone}`,
                    type: "numericColumn",
                    valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                },
                {
                    headerName: "APP Default",
                    field: `default_${zone}`,
                    type: "numericColumn",
                    valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                },
            ],
        }));

        return [
            {
                headerName: "App Description",
                field: "appType",
                pinned: "left",
                cellStyle: (params) => (params.value === "Total" ? { fontWeight: "bold", backgroundColor: "#f3f4f6" } : null),
            },
            ...zoneColumns,
            {
                headerName: "TOTAL",
                children: [
                    {
                        headerName: "Nos",
                        field: "totalNos",
                        type: "numericColumn",
                        valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                    },
                    {
                        headerName: "APP Success",
                        field: "totalSuccess",
                        type: "numericColumn",
                        valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                    },
                    {
                        headerName: "APP Default",
                        field: "totalDefault",
                        type: "numericColumn",
                        valueFormatter: (params) => params.value != null ? Number(params.value).toLocaleString("en-IN") : "0",
                    },
                ],
            },
        ];
    };

    // Main Fetch Function
    const fetchGridData = useCallback(async (selectedYear, selectedMonth, appTypes, officers, thresh) => {
        if (!selectedYear) return;

        const payLoadData = {
            Year: String(selectedYear),
            Month: selectedMonth.length > 0 ? selectedMonth.join(",") : "",
            APP_Type: appTypes.length > 0 ? appTypes.join(",") : "",
            Field_Officer_Code: officers.length > 0 ? officers.join(",") : "",
            Threshold: Number(thresh) || 75,
        };

        try {
            setGridLoading(true);
            const response = await fetch(`${hostUrl}/Master/GetAPPPerformanceCountZoneWise`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payLoadData),
            });

            if (!response.ok) throw new Error("Failed to fetch data");

            const result = await response.json();
            const gridResult = prepareGridData(result);

            setRowData(gridResult.rows);
            setColumnDefs(prepareGridColumns(gridResult.zones));
        } catch (error) {
            console.error("Error:", error);
            toast.error(error.message || "Error loading data");
            setRowData([]);
            setColumnDefs([]);
        } finally {
            setGridLoading(false);
        }
    }, []);

    // Load Grid Data Automatically on Page Render
    useEffect(() => {
        fetchGridData(year, month, categoryCode, fieldOfficerNames, threshold);
    }, []); // Runs once on Page Load

    const handleSubmit = (e) => {
        e?.preventDefault();
        fetchGridData(year, month, categoryCode, fieldOfficerNames, threshold);
    };

    // Dropdown Handlers
    const handleYearChange = (e) => {
        const selectedYear = e.target.value;
        setYear(selectedYear);
        setMonth([]);
    };

    const handleAppChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = categoryCode.length === categoryOptions.length && categoryOptions.length > 0;
        setCategoryCode(
            hasSelectAll
                ? (allSelected ? [] : categoryOptions.map((item) => String(item.id)))
                : options.filter((item) => !String(item.id).startsWith("__")).map((item) => String(item.id))
        );
    };

    const handleFieldOfficerChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = fieldOfficerCode.length === fieldOfficerOptions.length && fieldOfficerOptions.length > 0;
        setFieldOfficerCode(
            hasSelectAll
                ? (allSelected ? [] : fieldOfficerOptions.map((item) => String(item.id)))
                : options.filter((item) => !String(item.id).startsWith("__")).map((item) => String(item.id))
        );
        setFieldOfficerNames(
            hasSelectAll
                ? (allSelected ? [] : fieldOfficerOptions.map((item) => item.name))
                : options.filter((item) => !String(item.id).startsWith("__")).map((item) => item.name)
        );
    };

    const handleMonthChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = month.length === validFromMonths.length && validFromMonths.length > 0;
        setMonth(
            hasSelectAll
                ? (allSelected ? [] : validFromMonths.map((item) => item.value))
                : options.filter((item) => !String(item.id).startsWith("__")).map((item) => item.value)
        );
    };

    const selectedAppOptions = useMemo(() => categoryOptions.filter((item) => categoryCode.includes(String(item.id))), [categoryOptions, categoryCode]);
    const selectedMonthOptions = validFromMonths.filter((item) => month.includes(item.value));
    const selectedFieldOfficerOptions = useMemo(() => fieldOfficerOptions.filter((item) => fieldOfficerCode.includes(String(item.id))), [fieldOfficerOptions, fieldOfficerCode]);

    const CustomOption = (props) => (
        <components.Option {...props}>
            <div className="flex items-center gap-2">
                <input type="checkbox" checked={props.isSelected} onChange={() => null} className="cursor-pointer" />
                <span>{props.label}</span>
            </div>
        </components.Option>
    );

    const handleReset = () => {
        setYear(typeOptions[1].key);
        setMonth([]);
        setCategoryCode([]);
        setFieldOfficerCode([]);
        setFieldOfficerNames([]);
        setThreshold("75");
        fetchGridData(typeOptions[1].key, [], [], [], "75");
    };

    // Load Dropdown Options
    useEffect(() => {
        const fetchDropdowns = async () => {
            try {
                setLoading(true);
                const [appRes, officerRes] = await Promise.all([
                    fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ fy: year || currentFinancialYear }),
                    }),
                    fetch(`${hostUrl}/Master/GetAllFieldOfficer`)
                ]);

                if (appRes.ok) {
                    const appTypes = await appRes.json();
                    setCategoryOptions(
                        Array.isArray(appTypes) ? appTypes.map((item) => ({
                            ...item,
                            id: String(item.appCode ),
                            label:  item.label
                        })) : []
                    );
                }

                if (officerRes.ok) {
                    const officers = await officerRes.json();
                    setFieldOfficerOptions(
                        Array.isArray(officers) ? officers.map((item) => ({
                            ...item,
                            id: String(item.personaL_NO),
                            label: item.name,
                        })) : []
                    );
                }
            } catch (err) {
                console.error("Error loading dropdowns:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchDropdowns();
    }, [year]);

    // Excel Export
    const downloadExcel = async () => {
        if (rowData.length === 0 || columnDefs.length === 0) return;

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet("App Performance Status");
        const groupedColumns = columnDefs.filter((column) => Array.isArray(column.children));
        const headerRow1 = [columnDefs[0]?.headerName || "App Type"];
        const headerRow2 = [columnDefs[0]?.headerName || "App Type"];

        groupedColumns.forEach((group) => {
            headerRow1.push(group.headerName, ...Array(group.children.length - 1).fill(null));
            headerRow2.push(...group.children.map((column) => column.headerName));
        });

        worksheet.addRow(headerRow1);
        worksheet.addRow(headerRow2);

        let columnIndex = 2;
        groupedColumns.forEach((group) => {
            worksheet.mergeCells(1, columnIndex, 1, columnIndex + group.children.length - 1);
            columnIndex += group.children.length;
        });

        rowData.forEach((rowDataItem) => {
            const values = [rowDataItem[columnDefs[0].field]];
            groupedColumns.forEach((group) => {
                group.children.forEach((column) => {
                    values.push(rowDataItem[column.field] || 0);
                });
            });
            worksheet.addRow(values);
        });

        [1, 2].forEach((rowNumber) => {
            worksheet.getRow(rowNumber).eachCell((cell) => {
                cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
                cell.alignment = { vertical: "middle", horizontal: "center" };
                cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "1e3a8a" } };
                cell.border = { top: { style: "thin" }, left: { style: "thin" }, bottom: { style: "thin" }, right: { style: "thin" } };
            });
        });

        worksheet.columns.forEach((column) => { column.width = 16; });
        worksheet.getColumn(1).width = 24;

        const buffer = await workbook.xlsx.writeBuffer();
        saveAs(new Blob([buffer]), "App_Performance_Status.xlsx");
    };

    return (
        <div className="w-full">
            <ToastContainer />
            <div className="flex-1 p-6 pt-0">
                <div className="mx-auto">
                    <div className="bg-white rounded-lg shadow-lg">
                        <form onSubmit={handleSubmit} className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                                {/* YEAR */}
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Year <span className="text-red-500">*</span>
                                    </label>
                                    <select
                                        value={year}
                                        onChange={handleYearChange}
                                        className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                        required
                                    >
                                        {typeOptions.map((item) => (
                                            <option key={item.key} value={item.key}>{item.value}</option>
                                        ))}
                                    </select>
                                </div>

                                {/* MONTH */}
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">Month</label>
                                    <Select
                                        isMulti
                                        onChange={handleMonthChange}
                                        disabled={!year}
                                        isSearchable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[...selectionActions, ...monthOptions2]}
                                        value={selectedMonthOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        components={{ Option: CustomOption }}
                                        placeholder="Select Month"
                                        className="w-full"
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
                                    />
                                </div>

                                {/* APP TYPE */}
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">App Type</label>
                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[...selectionActions, ...categoryOptions]}
                                        value={selectedAppOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        onChange={handleAppChange}
                                        components={{ Option: CustomOption }}
                                        placeholder="Select App Type"
                                        className="w-full"
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
                                    />
                                </div>

                                {/* FIELD OFFICER */}
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">Field Officer</label>
                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[...selectionActions, ...fieldOfficerOptions]}
                                        value={selectedFieldOfficerOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        onChange={handleFieldOfficerChange}
                                        components={{ Option: CustomOption }}
                                        placeholder="Select Field Officer"
                                        className="w-full"
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
                                    />
                                </div>
                            </div>

                            {/* THRESHOLD */}
                            <div className="mt-5 max-w-xs">
                                <label className="block mb-2 font-medium text-gray-700">Threshold (%)</label>
                                <input
                                    type="number"
                                    value={threshold}
                                    onChange={(e) => setThreshold(e.target.value)}
                                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                                    placeholder="75"
                                />
                            </div>


                               <div className="flex justify-end gap-3 mt-6">

                               <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 font-medium transition"
                >
                  <RotateCcw className="w-4 h-4" /> Reset
                </button>

                                <button type="submit" disabled={gridLoading} className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition-colors disabled:bg-blue-300">
                                    {gridLoading ? "Searching..." : "Search"}
                                </button>
                            </div>

                         
                        </form>
                        </div>
                            <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
                                                <div className="flex justify-between items-center mb-4">
                                                    <h2 className="text-lg font-semibold text-gray-700">
                                                        App Performance Status List
                                                    </h2>
                                                    <div className="flex items-center gap-3">
                                                        {gridLoading && (<span className="text-sm text-blue-600 font-medium"> Loading Grid Data... </span>)}
                                                        <button
                                                            type="button"
                                                            onClick={downloadExcel}
                                                            disabled={gridLoading || rowData.length === 0}
                                                            className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                                                            title="Download Excel"
                                                        >
                                                              <Download className="w-4 h-4" /> Export Excel
                                                        </button>
                                                    </div>
                                                </div>
                                                <div
                                                    className="ag-theme-alpine"
                                                    style={{
                                                        height: "450px",
                                                        width: "100%",
                                                    }}
                                                >
                                                    <div className="ag-theme-alpine"
                                                        style={{
                                                            height: "400px",
                                                            width: "100%",
                                                            "--ag-header-background-color": "#dbeafe",
                                                            "--ag-header-foreground-color": "#1e3a8a",
                                                            "--ag-header-cell-hover-background-color": "#bfdbfe",
                                                            "--ag-header-column-separator-color": "#93c5fd",
                                                            "--ag-border-color": "#bfdbfe",
                                                            // "--ag-row-hover-color": "#eff6ff",
                                                            "--ag-odd-row-background-color": "#f8fbff"
                                                        }}
                                                    >
                                                        <AgGridReact
                                                             rowData={rowData}
                                                columnDefs={columnDefs}
                                                        loading={gridLoading}
                                                            pagination={true}
                                                            paginationPageSize={10}
                                                            defaultColDef={{
                                                                sortable: true,
                                                                resizable: true,
                                                                minWidth: 90,
                                                                width: 110,
                                                                maxWidth: 130,
                                                            }}
                                                            suppressAggFuncInHeader={true}
                                                            animateRows={true}
                                                            getRowStyle={(params) => {
                                                                if (params.data?.appType === "Total") {
                                                                    return {
                                                                        fontWeight: "bold",
                                                                        backgroundColor: "#0b5dc7",
                                                                        color: "white"
                                                                    };
                                                                }
                        
                                                                return null;
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>

                                            </div>

                        {/* GRID TABLE
                        <div className="p-6 pt-0">
                            <div className="ag-theme-alpine w-full h-[500px]">
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    loading={gridLoading}
                                    defaultColDef={{
                                        resizable: true,
                                        sortable: true,
                                        flex: 1,
                                        minWidth: 100,
                                    }}
                                />
                            </div>
                        </div> */}
                    </div>
                </div>
     
    
    );
};

export default Tab2AppPerformanceStatus;