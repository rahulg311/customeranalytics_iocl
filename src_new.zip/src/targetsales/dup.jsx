import React, {useState, useEffect, useMemo, useCallback} from 'react';
import {AgGridReact} from 'ag-grid-react';
import Header from '../components/header';
import Footer from '../components/footer';
import {ToastContainer, toast} from 'react-toastify';
import {hostUrl} from '../utils/constant';

const ContactUpdate = () => {
  const auTOptionsS = [
    {
      id: '1',
      label: 'Actual User',
      val: 'Actual User'
    },
    {
      id: '2',
      label: 'Traders',
      val: 'Traders'
    }
  ];

  const appSubTypeOptionsS = [
    {
      id: '1',
      label: 'Regular',
      val: 'Regular'
    },
    {
      id: '2',
      label: 'Monthly',
      val: 'Monthly'
    }
  ];

  const [Financialyear, setFinancialyear] = useState('');
  const [soldToParty, setSoldToParty] = useState('');
  const [validFrom, setValidFrom] = useState('');
  const [validTo, setValidTo] = useState('');
  const [zone, setZone] = useState('');
  const [fieldOfficer, setFieldOfficer] = useState('');
  const [auT, setAuT] = useState('');
  const [appSubType, setAppSubType] = useState('');
  const [appType, setAppType] = useState('');

  const [grade, setGrade] = useState('');
  const [Month, setMonth] = useState('');
  const [quantity, setQuantity] = useState('');
  const [ZoneCode, setZonecode] = useState('');

  // =========================
  // Required API Response State
  // =========================
  const [PERSONAL_NO, setPERSONAL_NO] = useState('');
  const [CustomerName, setCustomerName] = useState('');
  const [Parent_Code, setParent_Code] = useState('');
  const [Parent_Description, setParent_Description] = useState('');

  console.log(
    'Sssddd',
    'Financialyear:',
    Financialyear,
    'soldToParty:',
    soldToParty,
    'zone:',
    zone,
    'fieldOfficer:',
    fieldOfficer,
    'auT:',
    auT,
    'appSubType:',
    appSubType,
    'appType:',
    appType,
    'grade:',
    grade,
    'Month:',
    Month,
    'quantity:',
    quantity,
    'ZoneCode:',
    ZoneCode,
    'PERSONAL_NO:',
    PERSONAL_NO,
    'CustomerName:',
    CustomerName,
    'Parent_Code:',
    Parent_Code,
    'Parent_Description:',
    Parent_Description
  );

  // =========================
  // Dropdown Options
  // =========================
  const [SolidTopartyOptions, setSolidTopartyOptions] = useState([]);
  const [FieldOfficerOptions, setFieldOfficerOptions] = useState([]);
  const [zoneOptions, setZoneOptions] = useState([]);
  const [auTOptions, setAuTOptions] = useState(auTOptionsS);
  const [appSubTypeOptions, setAppSubTypeOptions] =
    useState(appSubTypeOptionsS);
  const [gradeOptions, setGradeOptions] = useState([]);
  const [ApptypeOptions, setApptypeOptions] = useState([]);

  console.log('gradeOptions', gradeOptions);

  // =========================
  // UI / Grid State
  // =========================
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // =========================
  // Financial Year
  // =========================
  const today = new Date();
  const currentYear = today.getFullYear();
  const month = today.getMonth();

  const financialYearStart = month >= 3 ? currentYear : currentYear - 1;

  const currentFinancialYear = `${financialYearStart}${String(
    financialYearStart + 1
  ).slice(-2)}`;

  const nextFinancialYear = `${financialYearStart + 1}${String(
    financialYearStart + 2
  ).slice(-2)}`;

  const FinancialYearOptions = [
    {
      key: currentFinancialYear,
      value: currentFinancialYear
    },
    {
      key: nextFinancialYear,
      value: nextFinancialYear
    }
  ];

  const [FinancialyearOptions, setFinancialyearOptions] =
    useState(FinancialYearOptions);

  // =========================
  // Fetch Dropdown Data
  // =========================
  const fetchDropdownData = useCallback(async () => {
    try {
      const results = await Promise.allSettled([
        fetch(`${hostUrl}/Master/GetAllSoldToParty`),
        fetch(`${hostUrl}/Master/GetAllFieldOfficer`),
        fetch(`${hostUrl}/Master/GetAllZoneCode`),
        fetch(`${hostUrl}/Master/GetAllGradeTargetMaster`),
        fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            fy: currentFinancialYear
          })
        })
      ]);

      const [soldtoparty, FieldOfficer, zoneRes, gradeRes, apptype] = results;

      console.log(gradeRes, zoneRes, 'zoneRes');

      // Sold To Party
      if (soldtoparty.status === 'fulfilled' && soldtoparty.value.ok) {
        const data = await soldtoparty.value.json();
        setSolidTopartyOptions(data);
      } else {
        console.error('Sold To Party API failed');
      }

      // Field Officer
      if (FieldOfficer.status === 'fulfilled' && FieldOfficer.value.ok) {
        const data = await FieldOfficer.value.json();
        setFieldOfficerOptions(
          data.map((item) => ({
            id: item.personaL_NO,
            label: item.name,
            personaL_NO: item.personaL_NO,
            name: item.name
          }))
        );
      } else {
        console.error('Field Officer API failed');
      }

      // Zone
      if (zoneRes.status === 'fulfilled' && zoneRes.value.ok) {
        const data = await zoneRes.value.json();
        setZoneOptions(
          data.map((item) => ({
            id: item.zo_Code,
            label: item.zo_Name
          }))
        );
      } else {
        console.error('Zone API failed');
      }

      // Grade Target Master
      if (gradeRes.status === 'fulfilled' && gradeRes.value.ok) {
        const data = await gradeRes.value.json();
        setGradeOptions(data);
      } else {
        console.error('Grade API failed');
      }

      // App Type
      if (apptype.status === 'fulfilled' && apptype.value.ok) {
        const data = await apptype.value.json();
        setApptypeOptions(data);
      } else {
        console.error('App Type API failed');
      }
    } catch (error) {
      console.error('Error fetching dropdown options:', error);
    }
  }, [currentFinancialYear]);

  // =========================
  // Fetch Grid Data
  // =========================
  const fetchContractData = useCallback(async () => {
    setGridLoading(true);

    try {
      const response = await fetch(`${hostUrl}/TargetSales/GetAllAppFY`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          year: currentFinancialYear,
          month: '0'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error(
          'Failed to fetch Contract List. Status:',
          response.status
        );
      }
    } catch (error) {
      console.error('GET API Error:', error);
    } finally {
      setGridLoading(false);
    }
  }, []);

  // =========================
  // Initial API Call
  // =========================
  useEffect(() => {
    fetchDropdownData();
    fetchContractData();
  }, [fetchDropdownData, fetchContractData]);

  // =========================
  // Submit
  // =========================
  const handleSubmit = async (e) => {
    e.preventDefault();

    const isUpdating = editIndex !== null;

    // 1. Separate Payload for Add / Create
    const addPayload = {
      Financialyear,
      soldToParty,
      CustomerName,
      validFrom,
      validTo,
      zone,
      ZoneCode,
      fieldOfficer,
      PERSONAL_NO,
      auT,
      appSubType,
      appType,
      grade,
      Parent_Code,
      Parent_Description,
      Month,
      quantity
    };

    // 2. Separate Payload for Edit / Update
    const updatePayload = {
      // Primary Filter Keys for Backend Matching
      Financialyear,
      Month,
      soldToParty,
      grade,

      // Updatable Data Fields
      CustomerName,
      status: 'A',
      // validFrom,
      // validTo,
      // zone,
      // ZoneCode,
      // fieldOfficer,
      // PERSONAL_NO,
      // auT,
      // appSubType,
      // appType,
      // Parent_Code,
      // Parent_Description,
      quantity
    };

    // Select payload and endpoint based on operation mode
    const payload = isUpdating ? updatePayload : addPayload;
    const apiUrl = isUpdating
      ? `${hostUrl}/Master/UpdateContractUpdate`
      : `${hostUrl}/Master/AddContractUpdate`;

    console.log(`${isUpdating ? 'UPDATE' : 'ADD'} PAYLOAD:`, payload);

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        toast.success(
          isUpdating
            ? 'Record Updated Successfully!'
            : 'Record Saved Successfully!'
        );

        handleReset();
        fetchContractData();
      } else {
        toast.warning(
          `Failed to ${isUpdating ? 'update' : 'save'} data. Status: ${
            response.status
          }`
        );
      }
    } catch (error) {
      toast.warning('Network or API Server Error!');
      console.error('API Error:', error);
    } finally {
      setLoading(false);
    }
  };
  // =========================
  // Edit
  // =========================
const handleEdit = (data, index) => {
  setFinancialyear(data.year || '');
  setSoldToParty(data.sold_To_Party || '');
  setCustomerName(data.customer_Name || '');
  setValidFrom(data.valid_From_Mon || '');
  setValidTo(data.valid_To_Mon || '');
  setZone(data.zo_Name || '');
  setZonecode(data.zo_Code || '');
  setFieldOfficer(data.field_Officer || '');
  setPERSONAL_NO(data.personaL_NO || '');
  setAuT(data.aU_T || '');
  setAppSubType(data.apP_Sub_Type || '');
  setAppType(data.apP_Type || '');
  setGrade(data.grade || '');
  setParent_Code(data.parent_Code || '');
  setParent_Description(data.parent_Description || '');
  setMonth(data.month || '');
  setQuantity(data.quantity || '');

  setEditIndex(index);
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

  // =========================
  // Reset
  // =========================
  const handleReset = () => {
    setFinancialyear('');
    setSoldToParty('');
    setCustomerName('');

    setValidFrom('');
    setValidTo('');

    setZone('');
    setZonecode('');

    setFieldOfficer('');
    setPERSONAL_NO('');

    setAuT('');
    setAppSubType('');
    setAppType('');

    setGrade('');
    setParent_Code('');
    setParent_Description('');

    setMonth('');
    setQuantity('');

    setEditIndex(null);
  };

 // =========================
// Grid Columns
// =========================
const columnDefs = useMemo(
  () => [
    {
      headerName: 'Financial year',
      field: 'year',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Sold To Party',
      field: 'sold_To_Party',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Customer',
      field: 'customer_Name',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Valid From',
      field: 'valid_From_Mon',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Valid To',
      field: 'valid_To_Mon',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Zone',
      field: 'zo_Name',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Field Officer',
      field: 'field_Officer',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'PERSONAL NO',
      field: 'personaL_NO',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'AU/T',
      field: 'aU_T',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'APP Sub Type',
      field: 'apP_Sub_Type',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Grade',
      field: 'grade',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Parent Code',
      field: 'parent_Code',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Parent Description',
      field: 'parent_Description',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Month',
      field: 'month',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Quantity',
      field: 'quantity',
      flex: 1,
      sortable: true,
      filter: true
    },
    {
      headerName: 'Action',
      width: 120,
      cellRenderer: (params) => (
        <div className="flex gap-2 mt-2">
          <button
            type="button"
            onClick={() => handleEdit(params.data, params.node.rowIndex)}
            className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
          >
            Edit
          </button>
        </div>
      )
    }
  ],
  []
);

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Contract Update" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* =========================
              FORM
          ========================= */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null
                  ? 'Edit Contract Update'
                  : 'Create Contract Update'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                {/* Financial Year */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Financial year <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={Financialyear}
                    onChange={(e) => setFinancialyear(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Financial year</option>
                    {FinancialyearOptions.map((item) => (
                      <option key={item.key} value={item.key}>
                        {item.value}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Sold To Party */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Sold To Party <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={soldToParty}
                    onChange={(e) => {
                      const value = JSON.parse(e.target.value);
                      setSoldToParty(value?.customer_Code);
                      setCustomerName(value?.cusT_NAME);
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Sold To Party</option>
                    {SolidTopartyOptions.map((item) => (
                      <option
                        key={item.id}
                        value={JSON.stringify({
                          customer_Code: item.customer_Code,
                          saleS_GROUP: item.saleS_GROUP,
                          cusT_NAME: item.cusT_NAME
                        })}
                      >
                        {item.customer_Code}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Valid From */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Valid From <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={validFrom}
                    onChange={(e) => setValidFrom(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* Valid To */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Valid To <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={validTo}
                    onChange={(e) => setValidTo(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* Zone */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Zone <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={zone}
                    onChange={(e) => setZone(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Zone</option>
                    {zoneOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Field Officer */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Field Officer <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={fieldOfficer}
                    onChange={(e) => {
                      const value = JSON.parse(e.target.value);
                      setFieldOfficer(value.name);
                      setPERSONAL_NO(value.personaL_NO);
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Field Officer</option>
                    {FieldOfficerOptions.map((item) => (
                      <option
                        key={item.id}
                        value={JSON.stringify({
                          name: item.name,
                          personaL_NO: item.personaL_NO
                        })}
                      >
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Zone Code */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Zone Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={ZoneCode}
                    onChange={(e) => {
                      const value = e.target.value;
                      setZonecode(value);
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Zone Code</option>
                    {zoneOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* AU/T */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    AU/T <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={auT}
                    onChange={(e) => setAuT(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select AU/T</option>
                    {auTOptions.map((item) => (
                      <option key={item.id} value={item.val}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* APP Sub Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    APP Sub Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={appSubType}
                    onChange={(e) => setAppSubType(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select APP Sub Type</option>
                    {appSubTypeOptions.map((item) => (
                      <option key={item.id} value={item.val}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* APP Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    APP Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={appType}
                    onChange={(e) => setAppType(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select APP Type</option>
                    {ApptypeOptions.map((item) => (
                      <option
                        key={item.id || item.apptype_Code}
                        value={item.id || item.apptype_Code}
                      >
                        {item.label || item.apptype_Name || item.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Grade */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={grade}
                    onChange={(e) => {
                      const value = JSON.parse(e.target.value);
                      setGrade(value.parent_Code);
                      setParent_Code(value?.parent_Code);
                      setParent_Description(value?.parent_Description);
                    }}
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">Select Grade</option>
                    {gradeOptions.map((item) => (
                      <option
                        key={item.id}
                        value={JSON.stringify({
                          parent_Code: item.parent_Code,
                          parent_Description: item.parent_Description,
                          type_Code: item.type_Code,
                          category_Code: item.category_Code
                        })}
                      >
                        {`${item.parent_Code}  -  ${item.parent_Description}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quantity */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Quantity <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="Enter Quantity"
                    min="0"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* Month */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Month <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={Month}
                    onChange={(e) => setMonth(e.target.value)}
                    placeholder="Enter Month details"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  disabled={loading}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded"
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded"
                >
                  {loading
                    ? 'Submitting...'
                    : editIndex !== null
                      ? 'Update'
                      : 'Submit'}
                </button>
              </div>
            </form>
          </div>

          {/* =========================
              GRID
          ========================= */}
          <div className="bg-white rounded-lg shadow-lg mt-6 p-6">
            <h3 className="text-lg font-semibold mb-4">Contract List</h3>
            <div className="ag-theme-alpine w-full h-96">
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                loading={gridLoading}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default ContactUpdate;
