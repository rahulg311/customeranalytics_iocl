import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";


import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";
import { hostUrl } from "../utils/constant";

// Base API URL declared outside component to prevent callback re-creations
const API_BASE_URL = `${hostUrl}/Master`

const RscMaster = () => {
  // Input States
  const [rscCode, setRscCode] = useState("");
  const [rscName, setRscName] = useState("");
  const [districtCode, setDistrictCode] = useState("");
  const [salesState, setSalesState] = useState("");
  const [maxStorageCapacity, setMaxStorageCapacity] = useState("");
  const [zoCode, setZoCode] = useState("");

  // Loading States
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);

  // Grid States
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // 1. Fetch All RSC Master List
  const fetchRscMasters = useCallback(async () => {
    setGridLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/GetAllRSCMaster`);
      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error("Failed to fetch RSC Master data. Status:", response.status);
        toast.error("Failed to load RSC Master list.");
      }
    } catch (error) {
      console.error("GET API Error:", error);
      toast.error("Network error while fetching RSC grid data.");
    } finally {
      setGridLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRscMasters();
  }, [fetchRscMasters]);

  // 2. Add / Update Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      rscCode: rscCode,
      rscName: rscName,
      districtCode: districtCode,
      salesState: salesState,
      maximumStorageCapacity: String(maxStorageCapacity),
      zoCode: zoCode,
    };

    const isUpdating = editIndex !== null;
    const apiUrl = isUpdating
      ? `${API_BASE_URL}/UpdateRSCMaster`
      : `${API_BASE_URL}/AddRSCMaster`;

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(
          isUpdating
            ? "RSC Master Record Updated Successfully!"
            : "RSC Master Record Added Successfully!"
        );
        handleReset();
        fetchRscMasters();
      } else {
        toast.warning(
          `Failed to ${isUpdating ? "update" : "save"} record. Status: ${response.status}`
        );
      }
    } catch (error) {
      console.error("Submit API Error:", error);
      toast.error("Network or Server Error!");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data, index) => {
    setRscCode(data.rscCode || data.RscCode || data.RSCCode || "");
    setRscName(data.rscName || data.RscName || data.RSCName || "");
    setDistrictCode(data.districtCode || data.DistrictCode || "");
    setSalesState(data.salesState || data.SalesState || "");
    setMaxStorageCapacity(
      data.maximumStorageCapacity ??
        data.maxStorageCapacity ??
        data.MaximumStorageCapacity ??
        ""
    );
    setZoCode(data.zoCode || data.ZoCode || data.zo_Code || "");

    setEditIndex(index);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    setRscCode("");
    setRscName("");
    setDistrictCode("");
    setSalesState("");
    setMaxStorageCapacity("");
    setZoCode("");
    setEditIndex(null);
  };

  const columnDefs = useMemo(
    () => [
      {
        headerName: "RSC Code",
        valueGetter: (params) =>
          params.data?.rscCode || params.data?.RscCode || params.data?.RSCCode || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "RSC Name",
        valueGetter: (params) =>
          params.data?.rscName || params.data?.RscName || params.data?.RSCName || "",
        flex: 1.5,
        sortable: true,
        filter: true,
      },
      {
        headerName: "District Code",
        valueGetter: (params) => params.data?.districtCode || params.data?.DistrictCode || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Sales State",
        valueGetter: (params) => params.data?.salesState || params.data?.SalesState || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Max Storage Capacity",
        valueGetter: (params) =>
          params.data?.maximumStorageCapacity ??
          params.data?.maxStorageCapacity ??
          params.data?.MaximumStorageCapacity ??
          "",
        flex: 1.2,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Zone Code",
        valueGetter: (params) =>
          params.data?.zoCode || params.data?.ZoCode || params.data?.zo_Code || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Action",
        width: 120,
        cellRenderer: (params) => (
          <div className="flex items-center h-full">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node?.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
            >
              Edit
            </button>
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="RSC Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* CARD 1: FORM CARD */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null ? "Update RSC Master" : "Create RSC Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {/* RSC Code (Disabled in Edit Mode) */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    RSC Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={rscCode}
                    disabled={editIndex !== null}
                    onChange={(e) => setRscCode(e.target.value)}
                    placeholder="Enter RSC Code (e.g., R001)"
                    className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                      editIndex !== null ? "bg-gray-100 cursor-not-allowed" : ""
                    }`}
                    required
                  />
                </div>

                {/* RSC Name */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    RSC Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={rscName}
                    onChange={(e) => setRscName(e.target.value)}
                    placeholder="Enter RSC Name"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* District Code */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    District Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={districtCode}
                    onChange={(e) => setDistrictCode(e.target.value)}
                    placeholder="Enter District Code (e.g., D01)"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Sales State */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Sales State <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={salesState}
                    onChange={(e) => setSalesState(e.target.value)}
                    placeholder="Enter Sales State (e.g., Delhi)"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Maximum Storage Capacity */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Maximum Storage Capacity
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    value={maxStorageCapacity}
                    onChange={(e) => setMaxStorageCapacity(e.target.value)}
                    placeholder="Enter Capacity (e.g., 5000)"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Zone Code */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Zone Code (Zo Code) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={zoCode}
                    onChange={(e) => setZoCode(e.target.value)}
                    placeholder="Enter Zone Code (e.g., ZO01)"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
              </div>

              {/* Form Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 text-white px-5 py-2 rounded-md hover:bg-gray-600 transition-colors"
                  disabled={loading}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-300"
                >
                  {loading ? "Submitting..." : editIndex !== null ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* CARD 2: TABLE CARD */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">RSC Master List</h2>
              {gridLoading && (
                <span className="text-sm text-blue-600 font-medium">Loading Grid Data...</span>
              )}
            </div>

            <div className="ag-theme-alpine" style={{ height: "450px", width: "100%" }}>
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default RscMaster;