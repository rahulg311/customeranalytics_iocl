import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";



import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";
import { hostUrl } from "../utils/constant";

// Base API URL declared outside component to avoid re-creation on re-render
const API_BASE_URL = `${hostUrl}/Master`;

const ParentTypeMaster = () => {
  // Input States
  const [parentDescription, setParentDescription] = useState("");
  const [parentCode, setParentCode] = useState("");
  const [typeCode, setTypeCode] = useState("");
  const [categoryCode, setCategoryCode] = useState("");
     const [categoryOptions, setcategoryOptions] = useState([]);



  // Options State
  const [typeOptions, setTypeOptions] = useState([]);
  // const categoryOptions = [
  //   { id: "", label: "Select Category Code" },
  //   { id: "01", label: "Category 01" },
  //   { id: "02", label: "Category 02" },
  //   { id: "03", label: "Category 03" },
  // ];

  // Loading & Grid States
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // 1. Fetch All Parent Target Master Data
  const fetchParentTargets = useCallback(async () => {
    setGridLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/GetAllParentTargetMaster`);
      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error("Failed to fetch Parent Targets. Status:", response.status);
        toast.error("Failed to load list data.");
      }
    } catch (error) {
      console.error("GET API Error:", error);
      toast.error("Network error while fetching Parent Target list.");
    } finally {
      setGridLoading(false);
    }
  }, []);

  // 2. Fetch Type Master Options for Dropdown
  const fetchTypeOptions = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/GetAllTypeMaster`);
      if (response.ok) {
        const data = await response.json();
        const list = Array.isArray(data) ? data : data.data || [];
  
        setTypeOptions(list);
      } 
    } catch (error) {
      console.error("Error fetching Type Master options:", error);
      
    }
  }, []);



  useEffect(()=>{
  Categoryapicall()
  },[])



  async function Categoryapicall (){
    let response = await fetch(`${API_BASE_URL}/GetAllCategoryMaster`)
   if (response.ok) {
        const data = await response.json();
       setcategoryOptions(
          data.map((item) => ({
            id: item.category_Code,
            label: item.category_Desc,
          })))
      } else {
        console.error("Failed to fetch Parent Targets. Status:", response.status);
        toast.error("Failed to load list data.");
      }
    
  }
  useEffect(() => {
    fetchParentTargets();
    fetchTypeOptions();
  }, [fetchParentTargets, fetchTypeOptions]);

  // 3. Add / Update Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      ParentCode: parentCode,
      ParentDescription: parentDescription,
      TypeCode: typeCode,
      CategoryCode: categoryCode,
    };

    const isUpdating = editIndex !== null;
    const apiUrl = isUpdating
      ? `${API_BASE_URL}/UpdateParentTargetMaster`
      : `${API_BASE_URL}/AddParentTargetMaster`;

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(
          isUpdating
            ? "Parent Target Record Updated Successfully!"
            : "Parent Target Record Added Successfully!"
        );
        handleReset();
        fetchParentTargets();
      } else {
        toast.warning(
          `Failed to ${isUpdating ? "update" : "save"} record. Status: ${response.status}`
        );
      }
    } catch (error) {
      console.error("Submit API Error:", error);
      toast.error("Network or API Server Error!");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data, index) => {
    setParentCode(data.parentCode || "");
    setParentDescription(data.parentDescription || "");
    setTypeCode(data.TypeCode || data.typeCode || "");
    setCategoryCode(data.CategoryCode || data.categoryCode || "");

    setEditIndex(index);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    setParentCode("");
    setParentDescription("");
    setTypeCode("");
    setCategoryCode("");
    setEditIndex(null);
  };

  const columnDefs = useMemo(
    () => [
      {
        headerName: "Parent Code",
        valueGetter: (params) => params.data?.parentCode  || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Parent Description",
        valueGetter: (params) =>
          params.data?.parentDescription  || "",
        flex: 1.5,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Type Code",
        valueGetter: (params) => params.data?.TypeCode || params.data?.typeCode || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Category Code",
        valueGetter: (params) => params.data?.CategoryCode || params.data?.categoryCode || "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Action",
        width: 120,
        cellRenderer: (params) => (
          <div className="flex items-center h-full">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node?.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
            >
              Edit
            </button>
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Parent Type Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* CARD 1: FORM CARD */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null ? "Update Parent Type Master" : "Create Parent Type Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                {/* Parent Code (Disabled in Edit Mode) */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Parent Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={parentCode}
                    disabled={editIndex !== null}
                    onChange={(e) => setParentCode(e.target.value)}
                    placeholder="Enter Parent Code (e.g., 09999)"
                    className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                      editIndex !== null ? "bg-gray-100 cursor-not-allowed" : ""
                    }`}
                    required
                  />
                </div>

                {/* Parent Description */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Parent Description <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={parentDescription}
                    onChange={(e) => setParentDescription(e.target.value)}
                    placeholder="Enter Parent Description"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                {/* Type Code */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Type Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={typeCode}
                    onChange={(e) => setTypeCode(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    required
                  ><option value="">Select type  Code</option>
                    {typeOptions.map((item) => (
                      <option key={item.typeCode} value={item.typeCode}>
                        {item.typeName}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Category Code */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Category Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={categoryCode}
                    onChange={(e) => setCategoryCode(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                    required
                  > <option value="">Select Category Code</option>
                    {categoryOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Form Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-md transition-colors"
                  disabled={loading}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition-colors disabled:bg-blue-300"
                >
                  {loading ? "Submitting..." : editIndex !== null ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* CARD 2: TABLE CARD */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">Parent Type Master List</h2>
              {gridLoading && (
                <span className="text-sm text-blue-600 font-medium">Loading Grid Data...</span>
              )}
            </div>

            <div className="ag-theme-alpine" style={{ height: "450px", width: "100%" }}>
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default ParentTypeMaster;