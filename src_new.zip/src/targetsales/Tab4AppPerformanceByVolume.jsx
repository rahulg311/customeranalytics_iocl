import React, { useEffect, useState, useMemo, useCallback } from "react";
import { Download, RotateCcw, Search } from "lucide-react";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import Header from "../components/header";
import Footer from "../components/footer";
import { toast, ToastContainer } from "react-toastify";
import { AgGridReact } from "ag-grid-react";
import Select, { components } from "react-select";
import { hostUrl } from "../utils/constant";


const MONTH_KEYS = [
  { id: "1", label: "Apr" },
  { id: "2", label: "May" },
  { id: "3", label: "Jun" },
  { id: "4", label: "Jul" },
  { id: "5", label: "Aug" },
  { id: "6", label: "Sep" },
  { id: "7", label: "Oct" },
  { id: "8", label: "Nov" },
  { id: "9", label: "Dec" },
  { id: "10", label: "Jan" },
  { id: "11", label: "Feb" },
  { id: "12", label: "Mar" },
];

const Tab4AppPerformanceByVolume = () => {
  const today = new Date();
  const currentCalendarYear = today.getFullYear();
  const currentCalendarMonth = today.getMonth() + 1;

  const financialYearStart =
    currentCalendarMonth >= 4 ? currentCalendarYear : currentCalendarYear - 1;
  const currentFinancialYear = `${financialYearStart}${String(
    financialYearStart + 1
  ).slice(-2)}`;
  const previousFinancialYear = `${financialYearStart - 1}${String(
    financialYearStart
  ).slice(-2)}`;

  const typeOptions = [
    { key: previousFinancialYear, value: previousFinancialYear },
    { key: currentFinancialYear, value: currentFinancialYear },
  ];

  // Component States
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);
  const [year, setYear] = useState(currentFinancialYear);

  // Zone States
  const [zoneCode, setZoneCode] = useState([]);
  const [zoneOptions, setZoneOptions] = useState([]);

  // App Type States
  const [categoryCode, setCategoryCode] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);

  // Field Officer States
  const [fieldOfficerCode, setFieldOfficerCode] = useState([]);
  const [fieldOfficerNames, setFieldOfficerNames] = useState([]);
  const [fieldOfficerOptions, setFieldOfficerOptions] = useState([]);

  // Threshold State
  const [threshold, setThreshold] = useState("75");

  // AG Grid States
  const [rowData, setRowData] = useState([]);
  const [columnDefs, setColumnDefs] = useState([]);

  const selectionActions = [{ id: "__select_all__", label: "Select All" }];

  // ----------------------------------------------------
  // INTEGRATED API CALLS
  // ----------------------------------------------------

  // 1. Fetch Zone Master Data
  const fetchZoneMasters = useCallback(async () => {
    try {
      const response = await fetch(`${hostUrl}/Master/ZoneMaster`);

      if (response.ok) {
        const data = await response.json();
        const rawList = Array.isArray(data) ? data : data.data || [];
        const formattedZones = rawList.map((item) => ({
          ...item,
          id: String(item.zo_Code),
          value: String(item.zo_Code),
          label: item.zo_Short_Name,
        }));
        setZoneOptions(formattedZones);
      } else {
        console.error("Failed to fetch Zone Master list. Status:", response.status);
        toast.error("Failed to load zone data.");
      }
    } catch (error) {
      console.error("GET API Error:", error);
      toast.error("Network error while fetching zone data.");
    }
  }, []);

  // 2. Fetch App Type Data
  const fetchAppTypes = useCallback(async () => {
    try {
      setLoading(true);
      const appData = await fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fy: year !== "" ? year : currentFinancialYear }),
      });

      if (!appData.ok) {
        throw new Error("Unable to fetch app types");
      }

      const appTypes = await appData.json();
      setCategoryOptions(
        Array.isArray(appTypes)
          ? appTypes.map((item) => ({
              ...item,
              id: String(item.appCode),
              value: String(item.appCode),
              label: item.label,
            }))
          : []
      );
      setCategoryCode([]);
    } catch (error) {
      console.error("Error fetching app types:", error);
      setCategoryOptions([]);
      setCategoryCode([]);
    } finally {
      setLoading(false);
    }
  }, [year, currentFinancialYear]);

  // 3. Fetch Field Officer Data
  const fetchFieldOfficers = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`${hostUrl}/Master/GetAllFieldOfficer`);

      if (!response.ok) {
        throw new Error("Unable to fetch field officer data");
      }

      const fieldOfficers = await response.json();
      setFieldOfficerOptions(
        Array.isArray(fieldOfficers)
          ? fieldOfficers.map((item) => ({
              ...item,
              id: String(item.personaL_NO),
              value: String(item.personaL_NO),
              label: item.name,
            }))
          : []
      );
      setFieldOfficerCode([]);
      setFieldOfficerNames([]);
    } catch (error) {
      console.error("Error fetching field officer data:", error);
      setFieldOfficerOptions([]);
      setFieldOfficerCode([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // ----------------------------------------------------
  // SELECT HANDLERS WITH "SELECT ALL" LOGIC
  // ----------------------------------------------------

  const handleZoneChange = (selectedOptions) => {
    const options = selectedOptions || [];
    const hasSelectAll = options.some((item) => item.id === "__select_all__");
    const allSelected =
      zoneCode.length === zoneOptions.length && zoneOptions.length > 0;

    const values = hasSelectAll
      ? allSelected
        ? []
        : zoneOptions.map((item) => String(item.id))
      : options
          .filter((item) => !String(item.id).startsWith("__"))
          .map((item) => String(item.id));

    setZoneCode(values);
  };

  const handleAppChange = (selectedOptions) => {
    const options = selectedOptions || [];
    const hasSelectAll = options.some((item) => item.id === "__select_all__");
    const allSelected =
      categoryCode.length === categoryOptions.length &&
      categoryOptions.length > 0;

    const values = hasSelectAll
      ? allSelected
        ? []
        : categoryOptions.map((item) => String(item.id))
      : options
          .filter((item) => !String(item.id).startsWith("__"))
          .map((item) => String(item.id));

    setCategoryCode(values);
  };

  const handleFieldOfficerChange = (selectedOptions) => {
    const options = selectedOptions || [];
    const hasSelectAll = options.some((item) => item.id === "__select_all__");
    const allSelected =
      fieldOfficerCode.length === fieldOfficerOptions.length &&
      fieldOfficerOptions.length > 0;

    setFieldOfficerCode(
      hasSelectAll
        ? allSelected
          ? []
          : fieldOfficerOptions.map((item) => String(item.id))
        : options
            .filter((item) => !String(item.id).startsWith("__"))
            .map((item) => String(item.id))
    );

    setFieldOfficerNames(
      hasSelectAll
        ? allSelected
          ? []
          : fieldOfficerOptions.map((item) => item.name)
        : options
            .filter((item) => !String(item.id).startsWith("__"))
            .map((item) => item.name)
    );
  };

  // Selected Option Mappings
  const selectedZoneOptions = useMemo(
    () => zoneOptions.filter((item) => zoneCode.includes(String(item.id))),
    [zoneOptions, zoneCode]
  );

  const selectedAppOptions = useMemo(
    () => categoryOptions.filter((item) => categoryCode.includes(String(item.id))),
    [categoryOptions, categoryCode]
  );

  const selectedFieldOfficerOptions = useMemo(
    () =>
      fieldOfficerOptions.filter((item) =>
        fieldOfficerCode.includes(String(item.id))
      ),
    [fieldOfficerOptions, fieldOfficerCode]
  );

  const CustomOption = (props) => (
    <components.Option {...props}>
      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={props.isSelected}
          onChange={() => null}
          className="cursor-pointer"
        />
        <span>{props.label}</span>
      </div>
    </components.Option>
  );

  const handleReset = () => {
    setYear(currentFinancialYear);
    setZoneCode([]);
    setCategoryCode([]);
    setFieldOfficerCode([]);
    setFieldOfficerNames([]);
    setThreshold("75");
    setRowData([]);
  };

  // ----------------------------------------------------
  // AG-GRID PREPARATION LOGIC
  // ----------------------------------------------------
  const prepareGridData = (apiData) => {
    if (!Array.isArray(apiData) || apiData.length === 0) return [];

    const appTypes = [...new Set(apiData.map((item) => item.app_Description))];
    const rows = [];

    const totalRow = { appType: "Total" };
    MONTH_KEYS.forEach((m) => {
      totalRow[`nos_${m.id}`] = 0;
      totalRow[`success_${m.id}`] = 0;
      totalRow[`default_${m.id}`] = 0;
    });
    totalRow.nos_annual = 0;
    totalRow.success_annual = 0;
    totalRow.default_annual = 0;

    appTypes.forEach((app) => {
      const row = { appType: app };
      let appNosAnnual = 0;
      let appSuccessAnnual = 0;
      let appDefaultAnnual = 0;

      MONTH_KEYS.forEach((m) => {
        const monthRecords = apiData.filter(
          (item) => item.app_Description === app && String(item.month) === m.id
        );

        const sumNos = monthRecords.reduce((acc, curr) => acc + Number(curr.nos || 0), 0);
        const sumSuccess = monthRecords.reduce((acc, curr) => acc + Number(curr.apP_Success || 0), 0);
        const sumDefault = monthRecords.reduce((acc, curr) => acc + Number(curr.apP_Default || 0), 0);

        row[`nos_${m.id}`] = sumNos;
        row[`success_${m.id}`] = sumSuccess;
        row[`default_${m.id}`] = sumDefault;

        appNosAnnual += sumNos;
        appSuccessAnnual += sumSuccess;
        appDefaultAnnual += sumDefault;

        totalRow[`nos_${m.id}`] += sumNos;
        totalRow[`success_${m.id}`] += sumSuccess;
        totalRow[`default_${m.id}`] += sumDefault;
      });

      row.nos_annual = appNosAnnual;
      row.success_annual = appSuccessAnnual;
      row.default_annual = appDefaultAnnual;

      totalRow.nos_annual += appNosAnnual;
      totalRow.success_annual += appSuccessAnnual;
      totalRow.default_annual += appDefaultAnnual;

      rows.push(row);
    });

    rows.push(totalRow);
    return rows;
  };

  const prepareGridColumns = () => {
    const formatNumber = (params) =>
      params.value != null ? Number(params.value).toLocaleString("en-IN") : "0";

    const createGroupChildren = (prefix) => {
      const monthCols = MONTH_KEYS.map((m) => ({
        headerName: m.label,
        field: `${prefix}_${m.id}`,
        type: "numericColumn",
        width: 80,
        valueFormatter: formatNumber,
      }));

      monthCols.push({
        headerName: "Annual",
        field: `${prefix}_annual`,
        type: "numericColumn",
        width: 95,
        valueFormatter: formatNumber,
        cellStyle: { fontWeight: "bold" },
      });

      return monthCols;
    };

    return [
      {
        headerName: "APP in No.",
        field: "appType",
        pinned: "left",
        width: 160,
        cellStyle: (params) => (params.value === "Total" ? { fontWeight: "bold" } : null),
      },
      {
        headerName: "No Of APP (No.)",
        children: createGroupChildren("nos"),
      },
      {
        headerName: "Successful APP (No.)",
        children: createGroupChildren("success"),
      },
      {
        headerName: "Default APP (No.)",
        children: createGroupChildren("default"),
      },
    ];
  };

  // Main API Submit Function
  const handleSubmit = async (e) => {
    e?.preventDefault();

    const payload = {
      Year: year || currentFinancialYear,
      Zone: zoneCode.join(","),
      AppType: categoryCode.join(","),
      FieldOfficer: fieldOfficerNames.length > 0 ? fieldOfficerNames.join(",") : null,
      Threshold: Number(threshold) || 75,
    };

    try {
      setGridLoading(true);
      const response = await fetch(
        `${hostUrl}/Master/GetAPPPerformanceCountVolumeZoneWise`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) throw new Error("Failed to fetch performance count data");

      const result = await response.json();
      const rows = prepareGridData(result);
      const cols = prepareGridColumns();

      setRowData(rows);
      setColumnDefs(cols);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Failed to load APP Performance Count Data");
      setRowData([]);
      setColumnDefs([]);
    } finally {
      setGridLoading(false);
    }
  };

  // Initial Data Load
  useEffect(() => {
    fetchZoneMasters();
    fetchFieldOfficers();
    handleSubmit();
  }, [fetchZoneMasters, fetchFieldOfficers]);

  useEffect(() => {
    fetchAppTypes();
  }, [fetchAppTypes]);

  // Excel Export Logic
  const downloadExcel = async () => {
    if (rowData.length === 0 || columnDefs.length === 0) {
      toast.warn("No data available to download!");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("APP Performance Count");
    const groupedColumns = columnDefs.filter((col) => Array.isArray(col.children));

    const headerRow1 = [columnDefs[0].headerName];
    const headerRow2 = [columnDefs[0].headerName];

    groupedColumns.forEach((group) => {
      headerRow1.push(group.headerName, ...Array(group.children.length - 1).fill(null));
      headerRow2.push(...group.children.map((child) => child.headerName));
    });

    worksheet.addRow(headerRow1);
    worksheet.addRow(headerRow2);

    let colIdx = 2;
    groupedColumns.forEach((group) => {
      worksheet.mergeCells(1, colIdx, 1, colIdx + group.children.length - 1);
      colIdx += group.children.length;
    });

    rowData.forEach((row) => {
      const rowValues = [row[columnDefs[0].field]];
      groupedColumns.forEach((group) => {
        group.children.forEach((child) => {
          rowValues.push(row[child.field] || 0);
        });
      });
      worksheet.addRow(rowValues);
    });

    [1, 2].forEach((rowNum) => {
      worksheet.getRow(rowNum).eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
        cell.alignment = { vertical: "middle", horizontal: "center" };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "1E3A8A" },
        };
      });
    });

    worksheet.columns.forEach((col) => (col.width = 12));
    worksheet.getColumn(1).width = 20;

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "APP_Performance_Count_Report.xlsx");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* <Header headerName="App Performance Count" /> */}
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="flex-1 p-6">
        <div className=" mx-auto space-y-6">
          {/* FILTER CARD */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-800 border-b pb-3 mb-5">
              App Performance Filter
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {/* YEAR */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Year <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 outline-none bg-white focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    {typeOptions.map((item) => (
                      <option key={item.key} value={item.key}>
                        {item.value}
                      </option>
                    ))}
                  </select>
                </div>

                {/* ZONE */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">Zone</label>
                  <Select
                    isMulti
                    isSearchable
                    isClearable
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    options={[...selectionActions, ...zoneOptions]}
                    value={selectedZoneOptions}
                    getOptionValue={(option) => String(option.id)}
                    onChange={handleZoneChange}
                    components={{ Option: CustomOption }}
                    placeholder="Select Zone"
                    className="w-full"
                    styles={{
                      menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                    menuPortalTarget={document.body}
                  />
                </div>

                {/* APP TYPE */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">App Type</label>
                  <Select
                    isMulti
                    isSearchable
                    isClearable
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    options={[...selectionActions, ...categoryOptions]}
                    value={selectedAppOptions}
                    getOptionValue={(option) => String(option.id)}
                    onChange={handleAppChange}
                    components={{ Option: CustomOption }}
                    placeholder="Select App Type"
                    className="w-full"
                    styles={{
                      menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                    menuPortalTarget={document.body}
                  />
                </div>

                {/* FIELD OFFICER */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">Field Officer</label>
                  <Select
                    isMulti
                    isSearchable
                    isClearable
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    options={[...selectionActions, ...fieldOfficerOptions]}
                    value={selectedFieldOfficerOptions}
                    getOptionValue={(option) => String(option.id)}
                    onChange={handleFieldOfficerChange}
                    components={{ Option: CustomOption }}
                    placeholder="Select Field Officer"
                    className="w-full"
                    styles={{
                      menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                    menuPortalTarget={document.body}
                  />
                </div>

                {/* THRESHOLD */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">Threshold (%)</label>
                  <input
                    type="number"
                    value={threshold}
                    onChange={(e) => setThreshold(e.target.value)}
                    placeholder="75"
                    className="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  />
                </div>
              </div>

              {/* ACTION BUTTONS */}
              <div className="flex justify-end items-center gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 font-medium transition"
                >
                  <RotateCcw className="w-4 h-4" /> Reset
                </button>
                <button
                  type="submit"
                  disabled={gridLoading || loading}
                  className="flex items-center gap-2 px-5 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium transition"
                >
                  <Search className="w-4 h-4" /> Search
                </button>
              </div>
            </form>
          </div>

          {/* AG-GRID TABLE CARD */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-800">
                All India Performance Count
              </h3>
              <button
                type="button"
                onClick={downloadExcel}
                disabled={rowData.length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium transition disabled:opacity-50"
              >
                <Download className="w-4 h-4" /> Export Excel
              </button>
            </div>
   <div
                            className="ag-theme-alpine"
                            style={{
                                height: "450px",
                                width: "100%",
                            }}
                        >
                            <div className="ag-theme-alpine"
                                style={{
                                    height: "400px",
                                    width: "100%",
                                    "--ag-header-background-color": "#dbeafe",
                                    "--ag-header-foreground-color": "#1e3a8a",
                                    "--ag-header-cell-hover-background-color": "#bfdbfe",
                                    "--ag-header-column-separator-color": "#93c5fd",
                                    "--ag-border-color": "#bfdbfe",
                                    // "--ag-row-hover-color": "#eff6ff",
                                    "--ag-odd-row-background-color": "#f8fbff"
                                }}
                            >
                                <AgGridReact
                                           rowData={rowData}
                columnDefs={columnDefs}
                loading={gridLoading}
                                    pagination={true}
                                  
                                    paginationPageSize={10}
                                    defaultColDef={{
                                        sortable: true,
                                        resizable: true,
                                        minWidth: 90,
                                        width: 110,
                                        maxWidth: 130,
                                    }}
                                    suppressAggFuncInHeader={true}
                                    animateRows={true}
                                    getRowStyle={(params) => {
                                        if (params.data?.appType === "Total") {
                                            return {
                                                fontWeight: "bold",
                                                backgroundColor: "#0b5dc7",
                                                color: "white"
                                            };
                                        }

                                        return null;
                                    }}
                                />
                            </div>
                        </div>
        
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Tab4AppPerformanceByVolume;