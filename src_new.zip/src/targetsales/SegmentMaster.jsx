import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";


import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";
import { hostUrl } from "../utils/constant";

// Base API URL
const API_BASE_URL = `${hostUrl}/Master`;

const SegmentMaster = () => {
  
  const [segmentCode, setSegmentCode] = useState("");
  const [segmentDesc, setSegmentDesc] = useState("");


  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);


  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);


  const fetchSegmentMasters = useCallback(async () => {
    setGridLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/GetAllSegmentMaster`);
      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error("Failed to fetch Segment Master data. Status:", response.status);
        toast.error("Failed to load Segment Master list.");
      }
    } catch (error) {
      console.error("GET API Error:", error);
      toast.error("Network error while fetching grid data.");
    } finally {
      setGridLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSegmentMasters();
  }, [fetchSegmentMasters]);


  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      segmentCode: Number(segmentCode),
      segmentDesc: segmentDesc,
    };

    const isUpdating = editIndex !== null;
    const apiUrl = isUpdating
      ? `${API_BASE_URL}/UpdateSegmentMaster`
      : `${API_BASE_URL}/AddSegmentMaster`;

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(
          isUpdating
            ? "Segment Master Record Updated Successfully!"
            : "Segment Master Record Added Successfully!"
        );
        handleReset();
        fetchSegmentMasters();
      } else {
        toast.warning(
          `Failed to ${isUpdating ? "update" : "save"} record. Status: ${response.status}`
        );
      }
    } catch (error) {
      console.error("Submit API Error:", error);
      toast.error("Network or Server Error!");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data, index) => {
    setSegmentCode(data.segmentCode ?? data.SegmentCode ?? "");
    setSegmentDesc(data.segmentDesc || data.SegmentDesc || "");
    setEditIndex(index);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleReset = () => {
    setSegmentCode("");
    setSegmentDesc("");
    setEditIndex(null);
  };

  const columnDefs = useMemo(
    () => [
      {
        headerName: "Segment Code",
        valueGetter: (params) =>
          params.data?.segmentCode ?? params.data?.SegmentCode ?? "",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Segment Description",
        valueGetter: (params) =>
          params.data?.segmentDesc || params.data?.SegmentDesc || "",
        flex: 2,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Action",
        width: 120,
        cellRenderer: (params) => (
          <div className="flex items-center h-full">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node?.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
            >
              Edit
            </button>
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Segment Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* CARD 1: FORM CARD */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null
                  ? "Update Segment Master"
                  : "Create Segment Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* Segment Code (Disabled in Edit Mode) */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Segment Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={segmentCode}
                    disabled={editIndex !== null}
                    onChange={(e) => setSegmentCode(e.target.value)}
                    placeholder="Enter Segment Code (e.g., 1)"
                    className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                      editIndex !== null ? "bg-gray-100 cursor-not-allowed" : ""
                    }`}
                    required
                  />
                </div>

                {/* Segment Description */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Segment Description <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={segmentDesc}
                    onChange={(e) => setSegmentDesc(e.target.value)}
                    placeholder="e.g., Retail, PP, Dedicated"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
              </div>

              {/* Form Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-md transition-colors"
                  disabled={loading}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition-colors disabled:bg-blue-300"
                >
                  {loading
                    ? "Submitting..."
                    : editIndex !== null
                    ? "Update"
                    : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* CARD 2: TABLE CARD */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">
                Segment List
              </h2>
              {gridLoading && (
                <span className="text-sm text-blue-600 font-medium">
                  Loading Grid Data...
                </span>
              )}
            </div>

            <div
              className="ag-theme-alpine"
              style={{ height: "450px", width: "100%" }}
            >
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default SegmentMaster;