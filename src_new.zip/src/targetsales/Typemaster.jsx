import React, { useState, useEffect, useMemo } from "react";
import { AgGridReact } from "ag-grid-react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Header from "../components/header";
import Footer from "../components/footer";
import { hostUrl } from "../utils/constant";

// API Base URL - adjust hostname/port as needed for your environment
const API_BASE_URL = `${hostUrl}/Master`;

const TypeMaster = () => {
  // Input States
  const [typeCode, setTypeCode] = useState("");
  const [typeDescription, setTypeDescription] = useState("");
  const [typeName, setTypeName] = useState("");

  // Grid & Action States
  const [rowData, setRowData] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Fetch initial list on component mount
  useEffect(() => {
    fetchTypeMasterList();
  }, []);

  const fetchTypeMasterList = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/GetAllTypeMaster`);
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }
      const data = await response.json();
      setRowData(data);
    } catch (error) {
      console.error("Error fetching Type Master data:", error);
      toast.error("Failed to fetch Type Master records.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!typeCode.trim() || !typeName.trim() || !typeDescription.trim()) {
      toast.warning("Please fill in all required fields.");
      return;
    }

    const payload = {
      typeCode: typeCode.trim(),
      typeName: typeName.trim(),
      typeDescription: typeDescription.trim(),
    };

    setSubmitting(true);
    const endpoint = isEditing ? "UpdateTypeMaster" : "AddTypeMaster";

    try {
      const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Failed to ${isEditing ? "update" : "add"} record.`);
      }

      toast.success(
        isEditing
          ? "Type Master updated successfully!"
          : "Type Master added successfully!"
      );

      handleReset();
      await fetchTypeMasterList(); // Refresh grid data
    } catch (error) {
      console.error(`Submit Error (${endpoint}):`, error);
      toast.error(`Failed to ${isEditing ? "update" : "add"} Type Master.`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (data) => {
    setTypeCode(data.typeCode);
    setTypeDescription(data.typeDescription);
    setTypeName(data.typeName);
    setIsEditing(true);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };


  const handleReset = () => {
    setTypeCode("");
    setTypeDescription("");
    setTypeName("");
    setIsEditing(false);
  };

  const columnDefs = useMemo(
    () => [
      {
        headerName: "Type Code",
        field: "typeCode",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Type Name",
        field: "typeName",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Type Description",
        field: "typeDescription",
        flex: 1,
        sortable: true,
        filter: true,
      },
      {
        headerName: "Action",
        width: 160,
        cellRenderer: (params) => (
          <div className="flex gap-2 items-center h-full py-1">
            <button
              type="button"
              onClick={() => handleEdit(params.data)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition"
            >
              Edit
            </button>
          
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <ToastContainer position="top-right" autoClose={3000} />
      <Header headerName="Type Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto max-w-">
          
          {/* CARD 1: FORM */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg flex justify-between items-center">
              <h2 className="text-xl font-semibold">
                {isEditing ? "Edit Type Master" : "Add Type Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* Type Code */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Type Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={typeCode}
                    onChange={(e) => setTypeCode(e.target.value)}
                    placeholder="Enter Type Code"
                    disabled={isEditing} // Code is disabled during edit mode
                    className={`w-full border rounded-md px-3 py-2 outline-none transition focus:ring-2 focus:ring-blue-500 ${
                      isEditing ? "bg-gray-100 cursor-not-allowed" : "bg-white"
                    }`}
                    required
                  />
                </div>

                {/* Type Name */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Type Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={typeName}
                    onChange={(e) => setTypeName(e.target.value)}
                    placeholder="e.g., PolyEthylene"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
                    required
                  />
                </div>

                {/* Type Description */}
                <div>
                  <label className="block mb-2 font-medium text-gray-700">
                    Type Description <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={typeDescription}
                    onChange={(e) => setTypeDescription(e.target.value)}
                    placeholder="e.g., PE, PP"
                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
                    required
                  />
                </div>

              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 text-white px-5 py-2 rounded-md hover:bg-gray-600 transition"
                  disabled={submitting}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition disabled:bg-blue-400"
                >
                  {submitting
                    ? "Saving..."
                    : isEditing
                    ? "Update"
                    : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* CARD 2: AG-GRID TABLE */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">
                Type Master List
              </h2>
            </div>

            <div
              className="ag-theme-alpine"
              style={{ height: "450px", width: "100%" }}
            >
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
                loading={loading}
              />
            </div>
          </div>

        </div>
      </div>

      <Footer />
    </div>
  );
};

export default TypeMaster;