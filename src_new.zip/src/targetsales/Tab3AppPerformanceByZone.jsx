import React, { useEffect, useState, useMemo, useCallback } from "react";
import { Download, RotateCcw } from "lucide-react";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import Header from "../components/header";
import { toast, ToastContainer } from "react-toastify";
import Footer from "../components/footer";
import { AgGridReact } from "ag-grid-react";
import Select, { components } from "react-select";
import { hostUrl } from '../utils/constant'

const Tab3AppPerformanceStatus = () => {
    const today = new Date();
    const currentCalendarYear = today.getFullYear();
    const currentCalendarMonth = today.getMonth() + 1;
    const API_BASE_URL = `${hostUrl}/Master`;

   

    // Financial Year starts from April
    const financialYearStart = currentCalendarMonth >= 4 ? currentCalendarYear : currentCalendarYear - 1;
    const currentFinancialYear = `${financialYearStart}${String(financialYearStart + 1).slice(-2)}`;
    const previousFinancialYear = `${financialYearStart - 1}${String(financialYearStart).slice(-2)}`;

    const typeOptions = [
        { key: previousFinancialYear, value: previousFinancialYear },
        { key: currentFinancialYear, value: currentFinancialYear },
    ];

    const [loading, setLoading] = useState(false);
    const [year, setYear] = useState(typeOptions[1].key);
    const [month, setMonth] = useState([]);
    const [performanceFrom, setPerformanceFrom] = useState("");
    const [performanceTo, setPerformanceTo] = useState("");
    const [includePerformanceFrom, setIncludePerformanceFrom] = useState(true);
    const [includePerformanceTo, setIncludePerformanceTo] = useState(true);
    const performanceFromMaximum = 125;
    const performanceToMaximum = 999;
    const [categoryCode, setCategoryCode] = useState([]);
    const [categoryOptions, setCategoryOptions] = useState([]);
    const [fieldOfficerCode, setFieldOfficerCode] = useState([]);
    const [fieldOfficerNames, setFieldOfficerNames] = useState([]);
    const [fieldOfficerOptions, setFieldOfficerOptions] = useState([]);
    const [gridLoading, setGridLoading] = useState(false);
    const [rowData, setRowData] = useState([]);
    const [columnDefs, setColumnDefs] = useState([]);



        const [zoneCode, setZoneCode] = useState([]);

const [zoneOptions, setZoneOptions] = useState([]);

    const months = [
        { id: 1, label: "April", value: "01" },
        { id: 2, label: "May", value: "02", },
        { id: 3, label: "June", value: "03", },
        { id: 4, label: "July", value: "04" },
        { id: 5, label: "August", value: "05", },
        { id: 6, label: "September", value: "06", },
        { id: 7, label: "October", value: "07", },
        { id: 8, label: "November", value: "08", },
        { id: 9, label: "December", value: "09", },
        { id: 10, label: "January", value: "10", },
        { id: 11, label: "February", value: "11", },
        { id: 12, label: "March", value: "12", },
    ];

    const currentFYMonth = currentCalendarMonth >= 4 ? currentCalendarMonth - 3 : currentCalendarMonth + 9;

    const validFromMonths = year === currentFinancialYear ? months.filter((item) => Number(item.value) <= currentFYMonth) : year === previousFinancialYear ? months : [];

    const selectionActions = [
        { id: "__select_all__", label: "Select All" },
    ];

    const monthOptions = [...selectionActions, ...validFromMonths];

    const handleYearChange = (e) => {
        const selectedYear = e.target.value;
        setYear(selectedYear);
        setMonth([]);
    };

    const handlePerformanceChange = (setter, maximum) => (e) => {
        const value = e.target.value;

        if (value === "") {
            setter("");
            return;
        }

        if (!/^\d*(\.\d*)?$/.test(value)) {
            return;
        }

        setter(String(Math.min(Number(value), maximum)));
    };

    const handleAppChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const actualOptions = categoryOptions;
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = categoryCode.length === actualOptions.length && actualOptions.length > 0;
        const values = hasSelectAll
            ? allSelected
                ? []
                : actualOptions.map((item) => String(item.id))
            : options
                .filter((item) => !String(item.id).startsWith("__"))
                .map((item) => String(item.id));

        setCategoryCode(values);
    };

    const selectedAppOptions = useMemo(() => {
        return categoryOptions.filter((item) =>
            categoryCode.includes(String(item.id))
        );
    }, [categoryOptions, categoryCode]);

    const handleFieldOfficerChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const actualOptions = fieldOfficerOptions;
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = fieldOfficerCode.length === actualOptions.length && actualOptions.length > 0;
        setFieldOfficerCode(
            hasSelectAll
                ? (allSelected ? [] : actualOptions.map((item) => String(item.id)))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => String(item.id))
        );
        setFieldOfficerNames(
            hasSelectAll
                ? (allSelected ? [] : actualOptions.map((item) => item.name))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => item.name)
        );
    };

    const handleMonthChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = month.length === validFromMonths.length && validFromMonths.length > 0;
        setMonth(
            hasSelectAll
                ? (allSelected ? [] : validFromMonths.map((item) => item.value))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => item.value)
        );
    };

    const selectedMonthOptions = validFromMonths.filter((item) =>
        month.includes(item.value)
    );

    const selectedFieldOfficerOptions = useMemo(() => {
        return fieldOfficerOptions.filter((item) =>
            fieldOfficerCode.includes(String(item.id))
        );
    }, [fieldOfficerOptions, fieldOfficerCode]);

    const CustomOption = (props) => {
        return (
            <components.Option {...props}>
                <div className="flex items-center gap-2">
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                        className="cursor-pointer"
                    />
                    <span>{props.label}</span>
                </div>
            </components.Option>
        );
    };

      const monthOptions2 = [...validFromMonths];

    const [performanceValue, setPerformanceValue] = useState("");
    const handleReset = () => {
        setYear("");
        setMonth([]);
          setZoneCode([]);
        setCategoryCode([]);
        setFieldOfficerCode([]);
        setFieldOfficerNames([]);
        setPerformanceFrom("");
        setPerformanceTo("");
        setIncludePerformanceFrom(true);
        setIncludePerformanceTo(true);
        setRowData([]);
        setColumnDefs([]);
    };

    // const prepareGridData = (apiData) => {
    //     if (!Array.isArray(apiData) || apiData.length === 0) {
    //         return [];
    //     }

    //     const zones = [...new Map(apiData.map(item => [item.zo_Code, {
    //                     code: item.zo_Code,
    //                     name: item.zo_Short_Name
    //                 }])).values()
    //     ];

    //     // Get unique App Types
    //     const appTypes = [...new Set(apiData.map(item => item.app_Description))];
    //     const result = [];

    //     appTypes.forEach(appType => {
    //         const row = {appType: appType};
    //         let grandTarget = 0;
    //         let grandSales = 0;
    //         zones.forEach(zone => {
    //             const zoneData = apiData.filter(item => item.app_Description === appType && item.zo_Code === zone.code);
    //             const target = zoneData.reduce(
    //                 (sum, item) => sum + Number(item.totalTarget || 0),
    //                 0
    //             );
    //             const sales = zoneData.reduce(
    //                 (sum, item) => sum + Number(item.totalSales || 0),
    //                 0
    //             );
    //             const achievement =
    //                 target > 0
    //                     ? Number(((sales / target) * 100).toFixed(2))
    //                     : 0;

    //             row[`target_${zone.code}`] = target;
    //             row[`sales_${zone.code}`] = sales;
    //             row[`achievement_${zone.code}`] = achievement;

    //             grandTarget += target;
    //             grandSales += sales;
    //         });

    //         row.totalTarget = grandTarget;
    //         row.totalSales = grandSales;
    //         row.totalAchievement =
    //             grandTarget > 0
    //                 ? Number(((grandSales / grandTarget) * 100).toFixed(2))
    //                 : 0;

    //         result.push(row);
    //     });

    //     const totalRow = {
    //         appType: "Total"
    //     };

    //     let overallTarget = 0;
    //     let overallSales = 0;

    //     zones.forEach(zone => {

    //         const zoneData = apiData.filter(
    //             item => item.zo_Code === zone.code
    //         );

    //         const target = zoneData.reduce(
    //             (sum, item) => sum + Number(item.totalTarget || 0),
    //             0
    //         );

    //         const sales = zoneData.reduce(
    //             (sum, item) => sum + Number(item.totalSales || 0),
    //             0
    //         );

    //         const achievement =
    //             target > 0
    //                 ? Number(((sales / target) * 100).toFixed(2))
    //                 : 0;

    //         totalRow[`target_${zone.code}`] = target;
    //         totalRow[`sales_${zone.code}`] = sales;
    //         totalRow[`achievement_${zone.code}`] = achievement;

    //         overallTarget += target;
    //         overallSales += sales;
    //     });

    //     totalRow.totalTarget = overallTarget;
    //     totalRow.totalSales = overallSales;
    //     totalRow.totalAchievement =
    //         overallTarget > 0
    //             ? Number(((overallSales / overallTarget) * 100).toFixed(2))
    //             : 0;

    //     result.push(totalRow);

    //     return {
    //         rows: result,
    //         zones
    //     };
    // };




    const monthsList = [
    { id: "1", key: "apr", label: "Apr" },
    { id: "2", key: "may", label: "May" },
    { id: "3", key: "jun", label: "Jun" },
    { id: "4", key: "jul", label: "Jul" },
    { id: "5", key: "aug", label: "Aug" },
    { id: "6", key: "sep", label: "Sep" },
    { id: "7", key: "oct", label: "Oct" },
    { id: "8", key: "nov", label: "Nov" },
    { id: "9", key: "dec", label: "Dec" },
    { id: "10", key: "jan", label: "Jan" },
    { id: "11", key: "feb", label: "Feb" },
    { id: "12", key: "mar", label: "Mar" },
];

const prepareGridData = (apiData) => {
    if (!Array.isArray(apiData) || apiData.length === 0) {
        return { rows: [], months: monthsList };
    }

    const appTypes = [...new Set(apiData.map(item => item.app_Description))];
    const result = [];

    appTypes.forEach(appType => {
        const row = { appType };
        let rowAnnualTarget = 0;
        let rowAnnualSales = 0;

        monthsList.forEach(m => {
            const monthData = apiData.filter(
                item => item.app_Description === appType && String(Number(item.month)) === m.id
            );

            const target = monthData.reduce((sum, item) => sum + Number(item.totalTarget || 0), 0);
            const sales = monthData.reduce((sum, item) => sum + Number(item.totalSales || 0), 0);

            row[`target_${m.id}`] = target;
            row[`sales_${m.id}`] = sales;

            rowAnnualTarget += target;
            rowAnnualSales += sales;
        });

        row.target_annual = rowAnnualTarget;
        row.sales_annual = rowAnnualSales;

        result.push(row);
    });

    // Total Row
    const totalRow = { appType: "Total" };
    let grandAnnualTarget = 0;
    let grandAnnualSales = 0;

    monthsList.forEach(m => {
        const monthData = apiData.filter(
            item => String(Number(item.month)) === m.id
        );

        const target = monthData.reduce((sum, item) => sum + Number(item.totalTarget || 0), 0);
        const sales = monthData.reduce((sum, item) => sum + Number(item.totalSales || 0), 0);

        totalRow[`target_${m.id}`] = target;
        totalRow[`sales_${m.id}`] = sales;

        grandAnnualTarget += target;
        grandAnnualSales += sales;
    });

    totalRow.target_annual = grandAnnualTarget;
    totalRow.sales_annual = grandAnnualSales;

    result.push(totalRow);

    return { rows: result, months: monthsList };
};

    const handleSubmit = async (e, isInitialLoad = false) => {
        e?.preventDefault();
        if(!year) {
            setRowData([]);
            setColumnDefs([]);
            return toast.error("Please select Year and Month before searching.");
        }
        if((Number(performanceTo) || 999) < (Number(performanceFrom) || 0)) {
            setRowData([]);
            setColumnDefs([]);
            return toast.error("Performance To cannot be less than Performance From.");
        }
        const payLoadData = {
            Year: year ? year : currentFinancialYear,
            // Month: month.join(","),
            Zone:zoneCode.join(","),
            AppType: categoryCode.join(","),
            // FieldOfficer: fieldOfficerCode.join(","),
            FieldOfficer: fieldOfficerNames.join(","),
            performanceFrom: isInitialLoad ? '0' : String(performanceFrom) || '0',
            performanceTo: isInitialLoad ? '999' : String(performanceTo) || '999',
            IncludePerformanceFrom: isInitialLoad ? true : includePerformanceFrom,
            IncludePerformanceTo: isInitialLoad ? true : includePerformanceTo
        };

        console.log("Payload:", payLoadData);
// return;
        try {
            setGridLoading(true);

            const response = await fetch(
                `${hostUrl}/Master/GetAPPPerformanceStatusZoneWise`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(payLoadData)
                }
            );

            if (!response.ok) {
                throw new Error("Unable to fetch performance data");
            }

            const result = await response.json();

            console.log("API Result:", result);

            // const gridResult = prepareGridData(result);

            // setRowData(gridResult.rows);
            // setColumnDefs(
            //     prepareGridColumns(gridResult.zones)
            // );


            const gridResult = prepareGridData(result);

setRowData(gridResult.rows);
setColumnDefs(prepareGridColumns());

        } catch (error) {
            console.error("Error:", error);
            setRowData([]);
            setColumnDefs([]);
        } finally {
            setGridLoading(false);
        }
    };

    const data = async () => {
        try {
            setLoading(true);
            const appData = await fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fy: year !== '' ? year : currentFinancialYear })
            })
            if (!appData.ok) {
                throw new Error('Unable to fetch app types');
            }

            const appTypes = await appData.json();
            setCategoryOptions(
                Array.isArray(appTypes)
                    ? appTypes.map((item) => ({
                        ...item,
                        value: String(item.id),
                        label: item.label,
                    }))
                    : []
            );
            setCategoryCode([]);
        } catch (error) {
            console.error('Error fetching app types:', error);
            setCategoryOptions([]);
            setCategoryCode([]);
        } finally {
            setLoading(false);
        }
    }

    const fieldOfficerData = async () => {

        try {
            setLoading(true);
            const response = await fetch(`${hostUrl}/Master/GetAllFieldOfficer`);
            if (!response.ok) {
                throw new Error('Unable to fetch field officer data');
            }
            const fieldOfficers = await response.json();
            setFieldOfficerOptions(
                Array.isArray(fieldOfficers)
                    ? fieldOfficers.map((item) => ({
                        ...item,
                        id: String(item.personaL_NO),
                        value: String(item.personaL_NO),
                        label: item.name,
                    }))
                    : []
            );
            setFieldOfficerCode([]);
            setFieldOfficerNames([]);
        } catch (error) {
            console.error('Error fetching field officer data:', error);
            setFieldOfficerOptions([]);
            setFieldOfficerCode([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
          fetchZoneMasters();
        fieldOfficerData();
        handleSubmit(undefined, true);
    }, []);

    useEffect(() => {
        data();
    }, [year])

    // grid columns function
    // const prepareGridColumns = (zones) => {

    //     const zoneColumns = zones.map(zone => ({
    //         headerName: zone.name,
    //         children: [
    //             {headerName: "Volume", field: `target_${zone.code}`, type: "numericColumn",
    //                 valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
    //                             maximumFractionDigits: 2
    //                         }) : "0"
    //             },
    //             {headerName: "Sale", field: `sales_${zone.code}`, type: "numericColumn",
    //                 valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
    //                             maximumFractionDigits: 2
    //                         })
    //                         : "0"
    //             },
    //             {headerName: "%", field: `achievement_${zone.code}`, type: "numericColumn",
    //                 valueFormatter: params => params.value != null ? `${Math.floor(Number(params.value)).toFixed(2)}%` : "0%"
    //             }
    //         ]
    //     }));

    //     return [
    //         {headerName: "", field: "appType", pinned: "left",
    //             cellStyle: params => {
    //                 if (params.value === "Total") {
    //                     return {
    //                         fontWeight: "bold"
    //                     };
    //                 }
    //                 return null;
    //             }
    //         },
    //         ...zoneColumns,
    //         {
    //             headerName: "TOTAL",
    //             children: [
    //                 {headerName: "Volume", field: "totalTarget", type: "numericColumn",
    //                     valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
    //                                 maximumFractionDigits: 2
    //                             }) : "0"
    //                 },
    //                 {headerName: "Sale", field: "totalSales", type: "numericColumn",
    //                     valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
    //                                 maximumFractionDigits: 2
    //                             })
    //                             : "0"
    //                 },
    //                 {headerName: "%", field: "totalAchievement", type: "numericColumn",
    //                     valueFormatter: params => params.value != null
    //                             ? `${Math.floor(Number(params.value)).toFixed(2)}%`
    //                             : "0%"
    //                 }
    //             ]
    //         }
    //     ];
    // };


    

    const prepareGridColumns = () => {
    const formatValue = (params) => {
        return params.value != null && params.value !== 0
            ? Math.floor(Number(params.value)).toLocaleString("en-IN")
            : "0";
    };

    const targetColumns = monthsList.map(m => ({
        headerName: m.label,
        field: `target_${m.id}`,
        type: "numericColumn",
        valueFormatter: formatValue
    }));

    targetColumns.push({
        headerName: "Annual",
        field: "target_annual",
        type: "numericColumn",
        cellStyle: { fontWeight: "bold" },
        valueFormatter: formatValue
    });

    const salesColumns = monthsList.map(m => ({
        headerName: m.label,
        field: `sales_${m.id}`,
        type: "numericColumn",
        valueFormatter: formatValue
    }));

    salesColumns.push({
        headerName: "Annual",
        field: "sales_annual",
        type: "numericColumn",
        cellStyle: { fontWeight: "bold" },
        valueFormatter: formatValue
    });

    return [
        {
            headerName: "APP in MT",
            field: "appType",
            pinned: "left",
            cellStyle: params => params.value === "Total" ? { fontWeight: "bold" } : null
        },
       {
    headerName: "APP (MT)",
    headerClass: "center-header",
    children: targetColumns
},
{
    headerName: "Sale (MT)",
    headerClass: "center-header",
    children: salesColumns
}
    ];
};

    // Fetch Zone Master Data
    const fetchZoneMasters = useCallback(async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/ZoneMaster`);

            if (response.ok) {
                const data = await response.json();
                const rawList = Array.isArray(data) ? data : data.data || [];
                const formattedZones = rawList.map((item) => ({
                    ...item,
                    id: String(item.zo_Code),
                    value: String(item.zo_Code),
                    label: item.zo_Short_Name,
                }));
                setZoneOptions(formattedZones);
            } else {
                console.error("Failed to fetch Zone Master list. Status:", response.status);
                toast.error("Failed to load zone data.");
            }
        } catch (error) {
            console.error("GET API Error:", error);
            toast.error("Network error while fetching zone data.");
        }
    }, [API_BASE_URL]);





     // Zone Handler
    const handleZoneChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const actualOptions = zoneOptions;
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = zoneCode.length === actualOptions.length && actualOptions.length > 0;
        const values = hasSelectAll
            ? allSelected
                ? []
                : actualOptions.map((item) => String(item.zo_Code))
            : options
                .filter((item) => !String(item.id).startsWith("__"))
                .map((item) => String(item.zo_Code || item.id));

        setZoneCode(values);
    };

    const selectedZoneOptions = useMemo(() => {
        return zoneOptions.filter((item) =>
            zoneCode.includes(String(item.zo_Code))
        );
    }, [zoneOptions, zoneCode]);

const downloadExcel = async () => {
    if (rowData.length === 0 || columnDefs.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Monthly Performance Status");

    const groupedColumns = columnDefs.filter(col => Array.isArray(col.children));

    const headerRow1 = ["APP in MT"];
    const headerRow2 = ["APP in MT"];

    groupedColumns.forEach(group => {
        headerRow1.push(group.headerName, ...Array(group.children.length - 1).fill(null));
        headerRow2.push(...group.children.map(child => child.headerName));
    });

    worksheet.addRow(headerRow1);
    worksheet.addRow(headerRow2);

    let colIdx = 2;
    groupedColumns.forEach(group => {
        worksheet.mergeCells(1, colIdx, 1, colIdx + group.children.length - 1);
        colIdx += group.children.length;
    });

    rowData.forEach(item => {
        const row = [item.appType];
        groupedColumns.forEach(group => {
            group.children.forEach(child => {
                row.push(item[child.field] || 0);
            });
        });
        worksheet.addRow(row);
    });

    [1, 2].forEach(rowNum => {
        worksheet.getRow(rowNum).eachCell(cell => {
            cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
            cell.alignment = { vertical: "middle", horizontal: "center" };
            cell.fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: "1e3a8a" }
            };
            cell.border = {
                top: { style: "thin" },
                left: { style: "thin" },
                bottom: { style: "thin" },
                right: { style: "thin" }
            };
        });
    });

    worksheet.columns.forEach(col => { col.width = 12; });
    worksheet.getColumn(1).width = 20;

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "Monthly_App_Performance.xlsx");
};

    return (
        <div className="">
            {/* HEADER */}
            {/* <Header headerName="App Performance Master" /> */}
            <div className="flex-1 p-6 pt-0">
                <div className="mx-auto">
                    <div className="bg-white rounded-lg shadow-lg">
                        {/* CARD HEADER */}
                        {/* <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                            <h2 className="text-xl font-semibold">
                                App Performance Status
                            </h2>
                        </div> */}
                        {/* FORM */}
                       <form
                        onSubmit={(e) => {
                            handleSubmit(e);
                        }}
                        className="p-6"
                    >
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">

                            {/* YEAR */}
                            <div>
                                <label className="block mb-2 font-medium text-gray-700">
                                    Year <span className="text-red-500">*</span>
                                </label>

                                <select
                                    value={year}
                                    onChange={handleYearChange}
                                    className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                    required
                                >
                                    <option value="" disabled>
                                        Select Year
                                    </option>

                                    {typeOptions.map((item) => (
                                        <option
                                            key={item.key}
                                            value={item.key}
                                        >
                                            {item.value}
                                        </option>
                                    ))}
                                </select>
                            </div>

                              {/* <div>
                                <label className="block mb-2 font-medium text-gray-700">
                                    Month <span className="text-red-500">*</span>
                                </label>

                                <Select
                                    onChange={handleMonthChange}
                                    disabled={!year}
                                    // isMulti
                                    isSearchable
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    options={monthOptions2}
                                    value={selectedMonthOptions}
                                    getOptionValue={(option) =>
                                        String(option.id)
                                    }
                                    components={{
                                        Option: CustomOption,
                                    }}
                                    placeholder={
                                        !year
                                            ? "Select Year First"
                                            : "Select Month"
                                    }
                                    className="w-full"
                                    menuPortalTarget={document.body}
                                    styles={{
                                        menuPortal: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                        }),
                                    }}
                                />
                            </div>  */}

                    {/* ZONE TYPE */}
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Zone Type
                                    </label>

                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[
                                            ...selectionActions,
                                            ...zoneOptions,
                                        ]}
                                        value={selectedZoneOptions}
                                        getOptionValue={(option) => String(option.zo_Code || option.id)}
                                        getOptionLabel={(option) => option.zo_Short_Name || option.label}
                                        onChange={handleZoneChange}
                                        components={{
                                            Option: CustomOption,
                                        }}
                                        placeholder="Select Zone Type"
                                        noOptionsMessage={() => "No Zone Type Found"}
                                        className="w-full"
                                        styles={{
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                            menuPortal: (base) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                        }}
                                        menuPortalTarget={document.body}
                                    />
                                </div>




                            {/* APP TYPE */}
                            <div>
                                <label className="block mb-2 font-medium text-gray-700">
                                    App Type
                                </label>

                                <Select
                                    isMulti
                                    isSearchable
                                    isClearable
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    options={[
                                        ...selectionActions,
                                        ...categoryOptions,
                                    ]}
                                    value={selectedAppOptions}
                                    getOptionValue={(option) =>
                                        String(option.id)
                                    }
                                    onChange={handleAppChange}
                                    components={{
                                        Option: CustomOption,
                                    }}
                                    placeholder="Select App Type"
                                    noOptionsMessage={() =>
                                        "No App Type Found"
                                    }
                                    className="w-full"
                                    styles={{
                                        menu: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                        }),
                                        menuPortal: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                        }),
                                    }}
                                    menuPortalTarget={document.body}
                                />
                            </div>

                            {/* FIELD OFFICER */}
                            <div>
                                <label className="block mb-2 font-medium text-gray-700">
                                    Field Officer
                                </label>

                                <Select
                                    isMulti
                                    isSearchable
                                    isClearable
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    options={[
                                        ...selectionActions,
                                        ...fieldOfficerOptions,
                                    ]}
                                    value={selectedFieldOfficerOptions}
                                    getOptionValue={(option) =>
                                        String(option.id)
                                    }
                                    onChange={handleFieldOfficerChange}
                                    components={{
                                        Option: CustomOption,
                                    }}
                                    placeholder="Select Field Officer"
                                    noOptionsMessage={() =>
                                        "No Field Officer Found"
                                    }
                                    className="w-full"
                                    styles={{
                                        menu: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                        }),
                                        menuPortal: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                        }),
                                    }}
                                    menuPortalTarget={document.body}
                                />

                                
                            </div>
                            {/* <div>
                                 <label className="block mb-2 font-medium text-gray-700">
                                Performance (%)
                            </label>

                            <input
                                type="number"
                                min="0"
                                max="100"
                                step="any"
                                value={performanceValue}
                                onChange={(e) => {
                                    let value = e.target.value;

                                    if (value === "") {
                                        setPerformanceValue("");
                                        return;
                                    }

                                    value = Number(value);

                                    if (value < 0) value = 0;
                                    if (value > 100) value = 100;

                                    setPerformanceValue(value);
                                }}
                                placeholder="Enter Performance %"
                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                            />
                            </div> */}

                                 <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Performance Range (%)
                                    </label>
                                    <div className="grid grid-cols-2 gap-3">
                                        <div>
                                            <label className="block mb-1 text-sm text-gray-600">From</label>
                                            <input
                                                type="number"
                                                min="0"
                                                max={performanceFromMaximum}
                                                step="any"
                                                value={performanceFrom}
                                                onChange={handlePerformanceChange(setPerformanceFrom, performanceFromMaximum)}
                                                placeholder="From"
                                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                                            />
                                            <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                                                <input
                                                    type="checkbox"
                                                    checked={includePerformanceFrom}
                                                    onChange={(e) => setIncludePerformanceFrom(e.target.checked)}
                                                    className="accent-blue-600"
                                                />
                                                Include From
                                            </label>
                                        </div>
                                        <div>
                                            <label className="block mb-1 text-sm text-gray-600">To</label>
                                            <input
                                                type="number"
                                                min="0"
                                                max={performanceToMaximum}
                                                step="any"
                                                value={performanceTo}
                                                onChange={handlePerformanceChange(setPerformanceTo, performanceToMaximum)}
                                                placeholder="To"
                                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                                            />
                                            <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                                                <input
                                                    type="checkbox"
                                                    checked={includePerformanceTo}
                                                    onChange={(e) => setIncludePerformanceTo(e.target.checked)}
                                                    className="accent-blue-600"
                                                />
                                                Include To
                                            </label>
                                        </div>
                                    </div>
                                </div>

                        </div>

                        {/* SINGLE PERFORMANCE INPUT */}
                        {/* <div className="mt-5 max-w-md">

                            <label className="block mb-2 font-medium text-gray-700">
                                Performance (%)
                            </label>

                            <input
                                type="number"
                                min="0"
                                max="100"
                                step="any"
                                value={performanceValue}
                                onChange={(e) => {
                                    let value = e.target.value;

                                    if (value === "") {
                                        setPerformanceValue("");
                                        return;
                                    }

                                    value = Number(value);

                                    if (value < 0) value = 0;
                                    if (value > 100) value = 100;

                                    setPerformanceValue(value);
                                }}
                                placeholder="Enter Performance %"
                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                            />

                        </div> */}

                        {/* BUTTONS */}
                        <div className="flex justify-end gap-3 mt-6">

                          <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 font-medium transition"
                >
                  <RotateCcw className="w-4 h-4" /> Reset
                </button>

                            <button
                                type="submit"
                                disabled={gridLoading}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition-colors disabled:bg-blue-300"
                            >
                                {gridLoading
                                    ? "Searching..."
                                    : "Search"}
                            </button>

                        </div>
                    </form>
                    </div>

                    <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-lg font-semibold text-gray-700">
                                App Performance Status List
                            </h2>
                            <div className="flex items-center gap-3">
                                {gridLoading && (<span className="text-sm text-blue-600 font-medium"> Loading Grid Data... </span>)}
                                <button
                                    type="button"
                                    onClick={downloadExcel}
                                    disabled={gridLoading || rowData.length === 0}
                                    className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                                    title="Download Excel"
                                >
                                     <Download className="w-4 h-4" /> Export Excel
                                </button>
                            </div>
                        </div>
                        <div
                            className="ag-theme-alpine"
                            style={{
                                height: "450px",
                                width: "100%",
                            }}
                        >
                            <div className="ag-theme-alpine"
                                style={{
                                    height: "400px",
                                    width: "100%",
                                    "--ag-header-background-color": "#dbeafe",
                                    "--ag-header-foreground-color": "#1e3a8a",
                                    "--ag-header-cell-hover-background-color": "#bfdbfe",
                                    "--ag-header-column-separator-color": "#93c5fd",
                                    "--ag-border-color": "#bfdbfe",
                                    // "--ag-row-hover-color": "#eff6ff",
                                    "--ag-odd-row-background-color": "#f8fbff"
                                }}
                            >
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    pagination={true}
                                     loading={gridLoading}
                                    paginationPageSize={10}
                                    defaultColDef={{
                                        sortable: true,
                                        resizable: true,
                                        minWidth: 90,
                                        width: 110,
                                        maxWidth: 130,
                                    }}
                                    suppressAggFuncInHeader={true}
                                    animateRows={true}
                                    getRowStyle={(params) => {
                                        if (params.data?.appType === "Total") {
                                            return {
                                                fontWeight: "bold",
                                                backgroundColor: "#0b5dc7",
                                                color: "white"
                                            };
                                        }

                                        return null;
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            {/* TOAST */}
            <ToastContainer
                position="top-right"
                autoClose={3000}
            />

        </div>
    );
};

export default Tab3AppPerformanceStatus;

