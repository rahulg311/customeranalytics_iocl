import React, {useState, useEffect, useMemo, useCallback} from 'react';
import {AgGridReact} from 'ag-grid-react';
import Header from '../components/header';
import Footer from '../components/footer';
import {ToastContainer, toast} from 'react-toastify';
import withSessionContext from '../HOC/withSessionContext';
import { hostUrl } from '../utils/constant';

const DopwMaster = (props) => {

     let UserNamelogin = props.sessionContext?.username ?? "";



  const API_BASE = hostUrl

  const ZONE_API = `${API_BASE}/Master/ZoneMaster`;
  const DCA_API = `${API_BASE}/Master/GetAllDCAMaster`;
  const DISTRICT_API = `${API_BASE}/Master/GetAllDistrictMaster`;
  const DOPW_GET_API = `${API_BASE}/Master/GetAllDOPWMaster`;
  const DOPW_ADD_API = `${API_BASE}/Master/AddDOPWMaster`;
  const DOPW_UPDATE_API = `${API_BASE}/Master/UpdateDOPWMaster`;

  // =========================================================
  // Static dropdowns
  // =========================================================
  const ownershipOptions = [
    {id: '1', value: 'Owned', label: 'Owned'},
    {id: '2', value: 'Rented', label: 'Rented'}
  ];

  const roofTypeOptions = [
    {id: '1', value: 'Covered', label: 'Covered'},
    {id: '2', value: 'Open', label: 'Open'}
  ];

  const statusOptions = [
    {id: '1', value: 'A', label: 'Active'},
    {id: '2', value: 'D', label: 'Deactive'}
  ];

  // =========================================================
  // Form state
  // =========================================================
  const [zoCode, setZoCode] = useState('');
  const [dcaCode, setDcaCode] = useState('');
  const [dopwCode, setDopwCode] = useState('');
  const [districtCode, setDistrictCode] = useState('');
  const [ownershipType, setOwnershipType] = useState('');
  const [roofType, setRoofType] = useState('');
  const [maximumStorageCapacity, setMaximumStorageCapacity] =
    useState('');
  const [activeFlag, setActiveFlag] = useState('');

  console.log("activeFlag",activeFlag)

  // =========================================================
  // Dropdown API state
  // =========================================================
  const [zoneOptions, setZoneOptions] = useState([]);
  const [dcaOptions, setDcaOptions] = useState([]);
  const [districtOptions, setDistrictOptions] = useState([]);

  // =========================================================
  // Grid / UI state
  // =========================================================
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);

  // =========================================================
  // Helper - API response data
  // =========================================================
  const getResponseData = async (response) => {
    const result = await response.json();

    if (Array.isArray(result)) {
      return result;
    }

    if (Array.isArray(result?.data)) {
      return result.data;
    }

    if (Array.isArray(result?.result)) {
      return result.result;
    }

    return result;
  };

  // =========================================================
  // Fetch Zone / DCA / District dropdowns
  // =========================================================
  const fetchDropdownData = useCallback(async () => {
    setGridLoading(true);

    try {
      const results = await Promise.allSettled([
        fetch(ZONE_API),
        fetch(DCA_API),
        fetch(DISTRICT_API)
      ]);

      const [zoneRes, dcaRes, districtRes] = results;

      if (zoneRes.status === 'fulfilled' && zoneRes.value.ok) {
        const data = await getResponseData(zoneRes.value);

        setZoneOptions(Array.isArray(data) ? data : []);
      } else {
        console.error('Zone API failed:', zoneRes.reason);
      }

      if (dcaRes.status === 'fulfilled' && dcaRes.value.ok) {
        const data = await getResponseData(dcaRes.value);

        setDcaOptions(Array.isArray(data) ? data : []);
      } else {
        console.error('DCA API failed:', dcaRes.reason);
      }

      if (
        districtRes.status === 'fulfilled' &&
        districtRes.value.ok
      ) {
        const data = await getResponseData(districtRes.value);

        setDistrictOptions(Array.isArray(data) ? data : []);
      } else {
        console.error('District API failed:', districtRes.reason);
      }
    } catch (error) {
      console.error('Dropdown API Error:', error);
      toast.error('Unable to load dropdown data');
    } finally {
      setGridLoading(false);
    }
  }, []);

  // =========================================================
  // Fetch DOPW grid data
  // =========================================================
  const fetchDOPWData = useCallback(async () => {
    setGridLoading(true);

    try {
      const response = await fetch(DOPW_GET_API);

      if (!response.ok) {
        throw new Error(`DOPW GET API failed: ${response.status}`);
      }

      const data = await getResponseData(response);

      setRowData(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('DOPW GET API Error:', error);
      toast.error('Unable to load DOPW Master data');
    } finally {
      setGridLoading(false);
    }
  }, []);

  // =========================================================
  // Initial API calls
  // =========================================================
  useEffect(() => {
    fetchDropdownData();
    fetchDOPWData();
  }, [fetchDropdownData, fetchDOPWData]);

  // =========================================================
  // Submit - Add / Update
  // =========================================================
  const handleSubmit = async (e) => {
    e.preventDefault();

    const isUpdating = editIndex !== null;

    const addPayload = {
      zo_Code: zoCode || '',
      dcA_Code: dcaCode || '',
      dopW_Code: dopwCode || '',
      district_Code: districtCode || '',
      ownership_Type: ownershipType || '',
      roof_Type: roofType || '',
      maximum_Storage_Capacity:
        Number(maximumStorageCapacity) || 0,
      active_Flag: activeFlag || '',
      created_By: UserNamelogin,
      Updated_By:""
    };

    const updatePayload = {
      zo_Code: zoCode || '',
      dcA_Code: dcaCode || '',
      dopW_Code: dopwCode || '',
      district_Code: districtCode || '',
      ownership_Type: ownershipType || '',
      roof_Type: roofType || '',
      maximum_Storage_Capacity:
        Number(maximumStorageCapacity) || 0,
      active_Flag: activeFlag || '',
      updated_By: UserNamelogin
    };

    const payload = isUpdating ? updatePayload : addPayload;
    const apiUrl = isUpdating ? DOPW_UPDATE_API : DOPW_ADD_API;

    setLoading(true);

    try {
      console.log(
        isUpdating ? 'Update DOPW Payload:' : 'Add DOPW Payload:',
        payload
      );

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      console.log('DOPW API Response:', result);

      if (response.ok) {
        toast.success(
          result?.message ||
            result?.Message ||
            `DOPW Master ${
              isUpdating ? 'updated' : 'added'
            } successfully`
        );

        handleReset();
        await fetchDOPWData();
      } else {
        toast.warning(
          result?.message ||
            result?.Message ||
            `Failed to ${
              isUpdating ? 'update' : 'add'
            } DOPW Master. Status: ${response.status}`
        );
      }
    } catch (error) {
      console.error('DOPW POST API Error:', error);
      toast.error('Network or API Server Error!');
    } finally {
      setLoading(false);
    }
  };

  // =========================================================
  // Edit
  // =========================================================
  const handleEdit = (data, index) => {
  
    setZoCode(data?.zo_Code || '');
    setDcaCode(data?.dcA_Code || '');
    setDopwCode(data?.dopW_Code || data?.dopw_Code || '');
    setDistrictCode(data?.district_Code || data?.District_Code || '' );
    setOwnershipType(data?.ownership_Type || '');
    setRoofType(data?.roof_Type || '');
    setMaximumStorageCapacity(data?.maximum_Storage_Capacity ?? '');

  // IMPORTANT
  const apiStatus = String(data?.active_Flag ?? '')
    .trim()
    .toUpperCase();

  console.log("STATUS AFTER CONVERT:", apiStatus);

  setActiveFlag(
    apiStatus === 'A'
      ? 'A'
      : apiStatus === 'D'
        ? 'D'
        : ''
  );

  setEditIndex(index);

  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
  };

  // =========================================================
  // Reset
  // =========================================================
  const handleReset = () => {
    setZoCode('');
    setDcaCode('');
    setDopwCode('');
    setDistrictCode('');
    setOwnershipType('');
    setRoofType('');
    setMaximumStorageCapacity('');
    setActiveFlag('');
    setEditIndex(null);
  };

  // =========================================================
  // Grid columns
  // =========================================================
  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Zo_Code',
        field: 'zo_Code',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'dcA_Code',
        field: 'dcA_Code',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'DOPW_Code',
        field: 'dopW_Code',
        flex: 1,
        sortable: true,
        filter: true,
        valueGetter: (params) =>
          params.data?.dopW_Code ||
          params.data?.dopw_Code ||
          ''
      },
      {
        headerName: 'District_Code',
        field: 'district_Code',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Ownership_Type',
        field: 'ownership_Type',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Roof_Type',
        field: 'roof_Type',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Maximum_Storage_Capacity',
        field: 'maximum_Storage_Capacity',
        flex: 1.5,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Active_Flag',
        field: 'active_Flag',
        flex: 1,
        sortable: true,
        filter: true,
        valueFormatter: (params) =>
          params.value === 'A'
            ? 'Active'
            : params.value === 'D'
              ? 'Deactive'
              : params.value || ''
      },
      {
        headerName: 'Created_By',
        field: 'created_By',
        flex: 1,
        sortable: true,
        filter: true
      },
      {
        headerName: 'Created_On',
        field: 'created_On',
        flex: 1,
        sortable: true,
        filter: true,
        valueFormatter: (params) =>
          params.value || 'NULL'
      },
      {
        headerName: 'Updated_By',
        field: 'updated_By',
        flex: 1,
        sortable: true,
        filter: true
      },
    //   {
    //     headerName: 'Updated_On',
    //     field: 'updated_On',
    //     flex: 1,
    //     sortable: true,
    //     filter: true,
    //     valueFormatter: (params) =>
    //       params.value || 'NULL'
    //   },
      {
        headerName: 'Action',
        width: 100,
        pinned: 'right',
        cellRenderer: (params) => (
          <div className="flex gap-2 mt-2">
            <button
              type="button"
              onClick={() =>
                handleEdit(
                  params.data,
                  params.node.rowIndex
                )
              }
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
            >
              Edit
            </button>
          </div>
        )
      }
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="DOPW Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">

          {/* =================================================
              FORM
          ================================================= */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null
                  ? 'Edit DOPW Master'
                  : 'Create DOPW Master'}
              </h2>
            </div>

            <form
              onSubmit={handleSubmit}
              className="p-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">

                {/* Zo Code */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Zo Code{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={zoCode}
                    onChange={(e) =>
                      setZoCode(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select Zo Code
                    </option>

                    {zoneOptions.map((item, index) => (
                      <option
                        key={
                          item.zo_Code || index
                        }
                        value={item.zo_Code || ''}
                      >
                        {item.zo_Code}
                        {item.zo_Name
                          ? ` - ${item.zo_Name}`
                          : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* DCA Code */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    DCA Code{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={dcaCode}
                    onChange={(e) =>
                      setDcaCode(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select DCA Code
                    </option>

                    {dcaOptions.map((item, index) => (
                      <option
                        key={
                          item.dcA_Code || index
                        }
                        value={item.dcA_Code || ''}
                      >
                        {item.dcA_Code}
                        {item.dcA_Name
                          ? ` - ${item.dcA_Name}`
                          : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* DOPW Code - INPUT */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    DOPW Code{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <input
                    type="text"
                    value={dopwCode}
                    onChange={(e) =>
                      setDopwCode(e.target.value)
                    }
                    placeholder="Enter DOPW Code"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* District Code */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    District Code{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={districtCode}
                    onChange={(e) =>
                      setDistrictCode(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select District Code
                    </option>

                    {districtOptions.map(
                      (item, index) => (
                        <option
                          key={
                            item.District_Code ||
                            item.district_Code ||
                            index
                          }
                          value={
                            item.District_Code ||
                            item.district_Code ||
                            ''
                          }
                        >
                          {item.District_Code ||
                            item.district_Code}
                          {item.District_Name
                            ? ` - ${item.District_Name}`
                            : ''}
                        </option>
                      )
                    )}
                  </select>
                </div>

                {/* Ownership Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Ownership Type{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={ownershipType}
                    onChange={(e) =>
                      setOwnershipType(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select Ownership Type
                    </option>

                    {ownershipOptions.map((item) => (
                      <option
                        key={item.id}
                        value={item.value}
                      >
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Roof Type */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Roof Type{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={roofType}
                    onChange={(e) =>
                      setRoofType(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select Roof Type
                    </option>

                    {roofTypeOptions.map((item) => (
                      <option
                        key={item.id}
                        value={item.value}
                      >
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Maximum Storage Capacity */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Maximum Storage Capacity{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <input
                    type="number"
                    min="0"
                    value={
                      maximumStorageCapacity
                    }
                    onChange={(e) =>
                      setMaximumStorageCapacity(
                        e.target.value
                      )
                    }
                    placeholder="Enter Maximum Storage Capacity"
                    required
                    className="w-full border rounded-md px-3 py-2"
                  />
                </div>

                {/* Active Flag */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Status{' '}
                    <span className="text-red-500">*</span>
                  </label>

                  <select
                    value={String(activeFlag)}
                    onChange={(e) =>
                      setActiveFlag(e.target.value)
                    }
                    required
                    className="w-full border rounded-md px-3 py-2"
                  >
                    <option value="">
                      Select Status
                    </option>

                    {statusOptions.map((item) => (
                      <option
                        key={item.id}
                        value={item.value}
                      >
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  disabled={loading}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded"
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded"
                >
                  {loading
                    ? 'Submitting...'
                    : editIndex !== null
                      ? 'Update'
                      : 'Submit'}
                </button>
              </div>
            </form>
          </div>

          {/* =================================================
              GRID
          ================================================= */}
          <div className="bg-white rounded-lg shadow-lg mt-6 p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">
              DOPW Master List
            </h3>

            <div className="ag-theme-alpine w-full  h-96">
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                loading={gridLoading}
                pagination={true}
                paginationPageSize={10}
                animateRows={true}
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />

      <ToastContainer
        position="top-right"
        autoClose={3000}
      />
    </div>
  );
};

export default withSessionContext(DopwMaster);