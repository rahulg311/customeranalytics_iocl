import React, { useEffect, useState, useMemo } from "react";
import { Download, RotateCcw } from "lucide-react";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import Header from "../components/header";
import { toast, ToastContainer } from "react-toastify";
import Footer from "../components/footer";
import { AgGridReact } from "ag-grid-react";
import Select, { components } from "react-select";
import { hostUrl } from '../utils/constant'

const Tab1AppPerformanceStatus = () => {
    const today = new Date();
    const currentCalendarYear = today.getFullYear();
    const currentCalendarMonth = today.getMonth() + 1;

    // Financial Year starts from April
    const financialYearStart = currentCalendarMonth >= 4 ? currentCalendarYear : currentCalendarYear - 1;
    const currentFinancialYear = `${financialYearStart}${String(financialYearStart + 1).slice(-2)}`;
    const previousFinancialYear = `${financialYearStart - 1}${String(financialYearStart).slice(-2)}`;

    const typeOptions = [
        { key: previousFinancialYear, value: previousFinancialYear },
        { key: currentFinancialYear, value: currentFinancialYear },
    ];

    const [loading, setLoading] = useState(false);
    const [year, setYear] = useState(typeOptions[1].key);
    const [month, setMonth] = useState([]);
    const [performanceFrom, setPerformanceFrom] = useState("");
    const [performanceTo, setPerformanceTo] = useState("");
    const [includePerformanceFrom, setIncludePerformanceFrom] = useState(true);
    const [includePerformanceTo, setIncludePerformanceTo] = useState(true);
    const performanceFromMaximum = 125;
    const performanceToMaximum = 999;
    const [categoryCode, setCategoryCode] = useState([]);
    const [categoryOptions, setCategoryOptions] = useState([]);
    const [fieldOfficerCode, setFieldOfficerCode] = useState([]);
    const [fieldOfficerNames, setFieldOfficerNames] = useState([]);
    const [fieldOfficerOptions, setFieldOfficerOptions] = useState([]);
    const [gridLoading, setGridLoading] = useState(false);
    const [rowData, setRowData] = useState([]);
    const [columnDefs, setColumnDefs] = useState([]);

    const months = [
        { id: 1, label: "April", value: "01" },
        { id: 2, label: "May", value: "02", },
        { id: 3, label: "June", value: "03", },
        { id: 4, label: "July", value: "04" },
        { id: 5, label: "August", value: "05", },
        { id: 6, label: "September", value: "06", },
        { id: 7, label: "October", value: "07", },
        { id: 8, label: "November", value: "08", },
        { id: 9, label: "December", value: "09", },
        { id: 10, label: "January", value: "10", },
        { id: 11, label: "February", value: "11", },
        { id: 12, label: "March", value: "12", },
    ];

    const currentFYMonth = currentCalendarMonth >= 4 ? currentCalendarMonth - 3 : currentCalendarMonth + 9;

    const validFromMonths = year === currentFinancialYear ? months.filter((item) => Number(item.value) <= currentFYMonth) : year === previousFinancialYear ? months : [];

    const selectionActions = [
        { id: "__select_all__", label: "Select All" },
    ];

    const monthOptions = [...selectionActions, ...validFromMonths];

    const handleYearChange = (e) => {
        const selectedYear = e.target.value;
        setYear(selectedYear);
        setMonth([]);
    };

    const handlePerformanceChange = (setter, maximum) => (e) => {
        const value = e.target.value;

        if (value === "") {
            setter("");
            return;
        }

        if (!/^\d*(\.\d*)?$/.test(value)) {
            return;
        }

        setter(String(Math.min(Number(value), maximum)));
    };

    const handleAppChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const actualOptions = categoryOptions;
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = categoryCode.length === actualOptions.length && actualOptions.length > 0;
        const values = hasSelectAll
            ? allSelected
                ? []
                : actualOptions.map((item) => String(item.id))
            : options
                .filter((item) => !String(item.id).startsWith("__"))
                .map((item) => String(item.id));

        setCategoryCode(values);
    };

    const selectedAppOptions = useMemo(() => {
        return categoryOptions.filter((item) =>
            categoryCode.includes(String(item.id))
        );
    }, [categoryOptions, categoryCode]);

    const handleFieldOfficerChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const actualOptions = fieldOfficerOptions;
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = fieldOfficerCode.length === actualOptions.length && actualOptions.length > 0;
        setFieldOfficerCode(
            hasSelectAll
                ? (allSelected ? [] : actualOptions.map((item) => String(item.id)))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => String(item.id))
        );
        setFieldOfficerNames(
            hasSelectAll
                ? (allSelected ? [] : actualOptions.map((item) => item.name))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => item.name)
        );
    };

    const handleMonthChange = (selectedOptions) => {
        const options = selectedOptions || [];
        const hasSelectAll = options.some((item) => item.id === "__select_all__");
        const allSelected = month.length === validFromMonths.length && validFromMonths.length > 0;
        setMonth(
            hasSelectAll
                ? (allSelected ? [] : validFromMonths.map((item) => item.value))
                : options
                    .filter((item) => !String(item.id).startsWith("__"))
                    .map((item) => item.value)
        );
    };

    const selectedMonthOptions = validFromMonths.filter((item) =>
        month.includes(item.value)
    );

    const selectedFieldOfficerOptions = useMemo(() => {
        return fieldOfficerOptions.filter((item) =>
            fieldOfficerCode.includes(String(item.id))
        );
    }, [fieldOfficerOptions, fieldOfficerCode]);

    const CustomOption = (props) => {
        return (
            <components.Option {...props}>
                <div className="flex items-center gap-2">
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                        className="cursor-pointer"
                    />
                    <span>{props.label}</span>
                </div>
            </components.Option>
        );
    };

    const handleReset = () => {
        setYear("");
        setMonth([]);
        setCategoryCode([]);
        setFieldOfficerCode([]);
        setFieldOfficerNames([]);
        setPerformanceFrom("");
        setPerformanceTo("");
        setIncludePerformanceFrom(true);
        setIncludePerformanceTo(true);
        setRowData([]);
        setColumnDefs([]);
    };

    const prepareGridData = (apiData) => {
        if (!Array.isArray(apiData) || apiData.length === 0) {
            return [];
        }

        const zones = [...new Map(apiData.map(item => [item.zo_Code, {
                        code: item.zo_Code,
                        name: item.zo_Short_Name
                    }])).values()
        ];

        // Get unique App Types
        const appTypes = [...new Set(apiData.map(item => item.app_Description))];
        const result = [];

        appTypes.forEach(appType => {
            const row = {appType: appType};
            let grandTarget = 0;
            let grandSales = 0;
            zones.forEach(zone => {
                const zoneData = apiData.filter(item => item.app_Description === appType && item.zo_Code === zone.code);
                const target = zoneData.reduce(
                    (sum, item) => sum + Number(item.totalTarget || 0),
                    0
                );
                const sales = zoneData.reduce(
                    (sum, item) => sum + Number(item.totalSales || 0),
                    0
                );
                const achievement =
                    target > 0
                        ? Number(((sales / target) * 100).toFixed(2))
                        : 0;

                row[`target_${zone.code}`] = target;
                row[`sales_${zone.code}`] = sales;
                row[`achievement_${zone.code}`] = achievement;

                grandTarget += target;
                grandSales += sales;
            });

            row.totalTarget = grandTarget;
            row.totalSales = grandSales;
            row.totalAchievement =
                grandTarget > 0
                    ? Number(((grandSales / grandTarget) * 100).toFixed(2))
                    : 0;

            result.push(row);
        });

        const totalRow = {
            appType: "Total"
        };

        let overallTarget = 0;
        let overallSales = 0;

        zones.forEach(zone => {

            const zoneData = apiData.filter(
                item => item.zo_Code === zone.code
            );

            const target = zoneData.reduce(
                (sum, item) => sum + Number(item.totalTarget || 0),
                0
            );

            const sales = zoneData.reduce(
                (sum, item) => sum + Number(item.totalSales || 0),
                0
            );

            const achievement =
                target > 0
                    ? Number(((sales / target) * 100).toFixed(2))
                    : 0;

            totalRow[`target_${zone.code}`] = target;
            totalRow[`sales_${zone.code}`] = sales;
            totalRow[`achievement_${zone.code}`] = achievement;

            overallTarget += target;
            overallSales += sales;
        });

        totalRow.totalTarget = overallTarget;
        totalRow.totalSales = overallSales;
        totalRow.totalAchievement =
            overallTarget > 0
                ? Number(((overallSales / overallTarget) * 100).toFixed(2))
                : 0;

        result.push(totalRow);

        return {
            rows: result,
            zones
        };
    };

    const handleSubmit = async (e, isInitialLoad = false) => {
        e?.preventDefault();
        if(!year) {
            setRowData([]);
            setColumnDefs([]);
            return toast.error("Please select Year and Month before searching.");
        }
        if((Number(performanceTo) || 999) < (Number(performanceFrom) || 0)) {
            setRowData([]);
            setColumnDefs([]);
            return toast.error("Performance To cannot be less than Performance From.");
        }
        const payLoadData = {
            Year: year ? year : currentFinancialYear,
            Month: month.join(","),
            AppType: categoryCode.join(","),
            // FieldOfficer: fieldOfficerCode.join(","),
            FieldOfficer: fieldOfficerNames.join(","),
            performanceFrom: isInitialLoad ? '0' : String(performanceFrom) || '0',
            performanceTo: isInitialLoad ? '999' : String(performanceTo) || '999',
            IncludePerformanceFrom: isInitialLoad ? true : includePerformanceFrom,
            IncludePerformanceTo: isInitialLoad ? true : includePerformanceTo
        };

        console.log("Payload:", payLoadData);
// return;
        try {
            setGridLoading(true);

            const response = await fetch(
                `${hostUrl}/Master/GetAPPPerformanceStatus`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(payLoadData)
                }
            );

            if (!response.ok) {
                throw new Error("Unable to fetch performance data");
            }

            const result = await response.json();

            console.log("API Result:", result);

            const gridResult = prepareGridData(result);

            setRowData(gridResult.rows);
            setColumnDefs(
                prepareGridColumns(gridResult.zones)
            );

        } catch (error) {
            console.error("Error:", error);
            setRowData([]);
            setColumnDefs([]);
        } finally {
            setGridLoading(false);
        }
    };

    const data = async () => {
        try {
            setLoading(true);
            const appData = await fetch(`${hostUrl}/TargetSales/GetAllAppType`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fy: year !== '' ? year : currentFinancialYear })
            })
            if (!appData.ok) {
                throw new Error('Unable to fetch app types');
            }

            const appTypes = await appData.json();
            setCategoryOptions(
                Array.isArray(appTypes)
                    ? appTypes.map((item) => ({
                        ...item,
                        value: String(item.id),
                        label: item.label,
                    }))
                    : []
            );
            setCategoryCode([]);
        } catch (error) {
            console.error('Error fetching app types:', error);
            setCategoryOptions([]);
            setCategoryCode([]);
        } finally {
            setLoading(false);
        }
    }

    const fieldOfficerData = async () => {

        try {
            setLoading(true);
            const response = await fetch(`${hostUrl}/Master/GetAllFieldOfficer`);
            if (!response.ok) {
                throw new Error('Unable to fetch field officer data');
            }
            const fieldOfficers = await response.json();
            setFieldOfficerOptions(
                Array.isArray(fieldOfficers)
                    ? fieldOfficers.map((item) => ({
                        ...item,
                        id: String(item.personaL_NO),
                        value: String(item.personaL_NO),
                        label: item.name,
                    }))
                    : []
            );
            setFieldOfficerCode([]);
            setFieldOfficerNames([]);
        } catch (error) {
            console.error('Error fetching field officer data:', error);
            setFieldOfficerOptions([]);
            setFieldOfficerCode([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fieldOfficerData();
        handleSubmit(undefined, true);
    }, []);

    useEffect(() => {
        data();
    }, [year])

    // grid columns function
    const prepareGridColumns = (zones) => {

        const zoneColumns = zones.map(zone => ({
            headerName: zone.name,
            children: [
                {headerName: "Volume", field: `target_${zone.code}`, type: "numericColumn",
                    valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
                                maximumFractionDigits: 2
                            }) : "0"
                },
                {headerName: "Sale", field: `sales_${zone.code}`, type: "numericColumn",
                    valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
                                maximumFractionDigits: 2
                            })
                            : "0"
                },
                {headerName: "%", field: `achievement_${zone.code}`, type: "numericColumn",
                    valueFormatter: params => params.value != null ? `${Math.floor(Number(params.value)).toFixed(2)}%` : "0%"
                }
            ]
        }));

        return [
            {headerName: "", field: "appType", pinned: "left",
                cellStyle: params => {
                    if (params.value === "Total") {
                        return {
                            fontWeight: "bold"
                        };
                    }
                    return null;
                }
            },
            ...zoneColumns,
            {
                headerName: "TOTAL",
                children: [
                    {headerName: "Volume", field: "totalTarget", type: "numericColumn",
                        valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
                                    maximumFractionDigits: 2
                                }) : "0"
                    },
                    {headerName: "Sale", field: "totalSales", type: "numericColumn",
                        valueFormatter: params => params.value != null ? Math.floor(Number(params.value)).toLocaleString("en-IN", {
                                    maximumFractionDigits: 2
                                })
                                : "0"
                    },
                    {headerName: "%", field: "totalAchievement", type: "numericColumn",
                        valueFormatter: params => params.value != null
                                ? `${Math.floor(Number(params.value)).toFixed(2)}%`
                                : "0%"
                    }
                ]
            }
        ];
    };

    const downloadExcel = async () => {
        if (rowData.length === 0 || columnDefs.length === 0) {
            return;
        }

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet("App Performance Status");
        const groupedColumns = columnDefs.filter((column) => Array.isArray(column.children));
        const headerRow1 = [columnDefs[0]?.headerName || "App Type"];
        const headerRow2 = [columnDefs[0]?.headerName || "App Type"];

        groupedColumns.forEach((group) => {
            headerRow1.push(group.headerName, ...Array(group.children.length - 1).fill(null));
            headerRow2.push(...group.children.map((column) => column.headerName));
        });

        worksheet.addRow(headerRow1);
        worksheet.addRow(headerRow2);

        let columnIndex = 2;
        groupedColumns.forEach((group) => {
            worksheet.mergeCells(1, columnIndex, 1, columnIndex + group.children.length - 1);
            columnIndex += group.children.length;
        });

        rowData.forEach((rowDataItem) => {
            const values = [rowDataItem[columnDefs[0].field]];

            groupedColumns.forEach((group) => {
                group.children.forEach((column) => {
                    const value = rowDataItem[column.field];
                    const isPercentageColumn = column.headerName === "%";
                    values.push(isPercentageColumn ? Number(value || 0) / 100 : value || 0);
                });
            });

            const row = worksheet.addRow(values);
            row.eachCell((cell, cellIndex) => {
                if (cellIndex > 1 && headerRow2[cellIndex - 1] === "%") {
                    cell.numFmt = "0.00%";
                }
            });
        });

        [1, 2].forEach((rowNumber) => {
            worksheet.getRow(rowNumber).eachCell((cell) => {
                cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
                cell.alignment = { vertical: "middle", horizontal: "center" };
                cell.fill = {
                    type: "pattern",
                    pattern: "solid",
                    fgColor: { argb: "1e3a8a" },
                };
                cell.border = {
                    top: { style: "thin" },
                    left: { style: "thin" },
                    bottom: { style: "thin" },
                    right: { style: "thin" },
                };
            });
        });

        worksheet.columns.forEach((column) => {
            column.width = 16;
        });
        worksheet.getColumn(1).width = 24;

        const buffer = await workbook.xlsx.writeBuffer();
        saveAs(new Blob([buffer]), "App_Performance_Status.xlsx");
    };

    return (
        <div className="">
            {/* HEADER */}
            {/* <Header headerName="App Performance Master" /> */}
            <div className="flex-1 p-6">
                <div className="mx-auto">
                    <div className="bg-white rounded-lg shadow-lg">
                        {/* CARD HEADER */}
                        {/* <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                            <h2 className="text-xl font-semibold">
                                App Performance Status
                            </h2>
                        </div> */}
                        {/* FORM */}
                        <form onSubmit={(e) => { handleSubmit(e); }} className="p-6 pt-0">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Year <span className="text-red-500"> {" "}* </span>
                                    </label>
                                    <select
                                        value={year}
                                        onChange={handleYearChange}
                                        className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                        required
                                    >
                                        <option value="" selected disabled>Select Year</option>
                                        {typeOptions.map((item) => (
                                            <option key={item.key} value={item.key}>
                                                {item.value}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Month <span className="text-red-500"> {" "}* </span>
                                    </label>

                                    <Select
                                        onChange={handleMonthChange}
                                        disabled={!year}
                                        isMulti
                                        isSearchable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={monthOptions}
                                        value={selectedMonthOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        components={{ Option: CustomOption }}
                                        placeholder={!year ? "Select Year First" : "Select Month"}
                                        className="w-full"
                                        menuPortalTarget={document.body}
                                        styles={{
                                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                                        }}
                                    >
                                    </Select>
                                </div>
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        App Type
                                    </label>
                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[...selectionActions, ...categoryOptions]}
                                        value={selectedAppOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        onChange={handleAppChange}
                                        components={{ Option: CustomOption }}
                                        placeholder="Select App Type"
                                        noOptionsMessage={() => "No App Type Found"}
                                        className="w-full"
                                        styles={{
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                            menuPortal: (
                                                base
                                            ) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                        }}
                                        menuPortalTarget={
                                            document.body
                                        }
                                    />
                                </div>
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Field Officer
                                    </label>
                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        options={[...selectionActions, ...fieldOfficerOptions]}
                                        value={selectedFieldOfficerOptions}
                                        getOptionValue={(option) => String(option.id)}
                                        onChange={handleFieldOfficerChange}
                                        components={{ Option: CustomOption }}
                                        placeholder="Select Field Officer"
                                        noOptionsMessage={() => "No Field Officer Found"}
                                        className="w-full"
                                        styles={{
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                            menuPortal: (
                                                base
                                            ) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                        }}
                                        menuPortalTarget={
                                            document.body
                                        }
                                    />
                                </div>
                                <div>
                                    <label className="block mb-2 font-medium text-gray-700">
                                        Performance Range (%)
                                    </label>
                                    <div className="grid grid-cols-2 gap-3">
                                        <div>
                                            <label className="block mb-1 text-sm text-gray-600">From</label>
                                            <input
                                                type="number"
                                                min="0"
                                                max={performanceFromMaximum}
                                                step="any"
                                                value={performanceFrom}
                                                onChange={handlePerformanceChange(setPerformanceFrom, performanceFromMaximum)}
                                                placeholder="From"
                                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                                            />
                                            <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                                                <input
                                                    type="checkbox"
                                                    checked={includePerformanceFrom}
                                                    onChange={(e) => setIncludePerformanceFrom(e.target.checked)}
                                                    className="accent-blue-600"
                                                />
                                                Include From
                                            </label>
                                        </div>
                                        <div>
                                            <label className="block mb-1 text-sm text-gray-600">To</label>
                                            <input
                                                type="number"
                                                min="0"
                                                max={performanceToMaximum}
                                                step="any"
                                                value={performanceTo}
                                                onChange={handlePerformanceChange(setPerformanceTo, performanceToMaximum)}
                                                placeholder="To"
                                                className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                                            />
                                            <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                                                <input
                                                    type="checkbox"
                                                    checked={includePerformanceTo}
                                                    onChange={(e) => setIncludePerformanceTo(e.target.checked)}
                                                    className="accent-blue-600"
                                                />
                                                Include To
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="flex justify-end gap-3 mt-6">

                        <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 font-medium transition"
                >
                  <RotateCcw className="w-4 h-4" /> Reset
                </button>

                                <button type="submit" disabled={gridLoading} className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition-colors disabled:bg-blue-300">
                                    {gridLoading ? "Searching..." : "Search"}
                                </button>
                            </div>
                        </form>
                    </div>

                    <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-lg font-semibold text-gray-700">
                                App Performance Status List
                            </h2>
                            <div className="flex items-center gap-3">
                                {gridLoading && (<span className="text-sm text-blue-600 font-medium"> Loading Grid Data... </span>)}
                                <button
                                    type="button"
                                    onClick={downloadExcel}
                                    disabled={gridLoading || rowData.length === 0}
                                    className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                                    title="Download Excel"
                                >
                                     <Download className="w-4 h-4" /> Export Excel
                                </button>
                            </div>
                        </div>
                        <div
                            className="ag-theme-alpine"
                            style={{
                                height: "450px",
                                width: "100%",
                            }}
                        >
                            <div className="ag-theme-alpine"
                                style={{
                                    height: "400px",
                                    width: "100%",
                                    "--ag-header-background-color": "#dbeafe",
                                    "--ag-header-foreground-color": "#1e3a8a",
                                    "--ag-header-cell-hover-background-color": "#bfdbfe",
                                    "--ag-header-column-separator-color": "#93c5fd",
                                    "--ag-border-color": "#bfdbfe",
                                    // "--ag-row-hover-color": "#eff6ff",
                                    "--ag-odd-row-background-color": "#f8fbff"
                                }}
                            >
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    pagination={true}
                                     loading={gridLoading}
                                    paginationPageSize={10}
                                    defaultColDef={{
                                        sortable: true,
                                        resizable: true,
                                        minWidth: 90,
                                        width: 110,
                                        maxWidth: 130,
                                    }}
                                    suppressAggFuncInHeader={true}
                                    animateRows={true}
                                    getRowStyle={(params) => {
                                        if (params.data?.appType === "Total") {
                                            return {
                                                fontWeight: "bold",
                                                backgroundColor: "#0b5dc7",
                                                color: "white"
                                            };
                                        }

                                        return null;
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            {/* TOAST */}
            <ToastContainer
                position="top-right"
                autoClose={3000}
            />

        </div>
    );
};

export default Tab1AppPerformanceStatus;

