import React, { useState } from "react";
import Header from "../components/header";
import Footer from "../components/footer";
import Tab1AppPerformanceStatus from "./Tab1AppPerformanceStatus";
import Tab2AppPerformanceStatus from "./Tab2AppPerformanceStatus";
import Tab3AppPerformanceByZone from "./Tab3AppPerformanceByZone";
import Tab4AppPerformanceByVolume from "./Tab4AppPerformanceByVolume";

const AppPerformanceMaster = () => {
    const [activeTab, setActiveTab] = useState(1);

    const renderTabContent = () => {
        switch (activeTab) {
            case 1:
                return <Tab1AppPerformanceStatus />;
            case 2:
                return <Tab2AppPerformanceStatus />;
            case 3:
                return <Tab3AppPerformanceByZone />;
            case 4:
                return <Tab4AppPerformanceByVolume />;
            default:
                return <Tab1AppPerformanceStatus />;
        }
    };

    const getTabTitle = () => {
        switch (activeTab) {
            case 1:
                return "App Performance Status";
            case 2:
                return "App Performance Count Status";
            case 3:
                return "APP Performance by Zonal Office";
            case 4:
                return "APP Performance Status by Volume";
            default:
                return "App Performance Status";
        }
    };

    return (
        <div className="min-h-screen flex flex-col bg-gray-100">
            {/* HEADER */}
            <Header headerName="App Performance Master" />

            <div className="flex-1 p-6">
                <div className="mx-auto">
                    <div className="bg-white rounded-lg shadow-lg">
                        {/* CARD HEADER & TABS */}
                        <div className="bg-blue-600 flex items-center justify-between text-white px-6 py-4 rounded-t-lg flex-wrap gap-4">
                            <h2 className="text-xl font-semibold">{getTabTitle()}</h2>

                            <div className="flex gap-2 flex-wrap">
                                <button
                                    type="button"
                                    onClick={() => setActiveTab(1)}
                                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                                        activeTab === 1
                                            ? "bg-white text-blue-600 font-bold"
                                            : "bg-blue-500 text-white hover:bg-blue-400"
                                    }`}
                                >
                                   Zone Wise App Performance 
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setActiveTab(2)}
                                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                                        activeTab === 2
                                            ? "bg-white text-blue-600 font-bold"
                                            : "bg-blue-500 text-white hover:bg-blue-400"
                                    }`}
                                >
                                      Zone Wise App Success 
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setActiveTab(3)}
                                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                                        activeTab === 3
                                            ? "bg-white text-blue-600 font-bold"
                                            : "bg-blue-500 text-white hover:bg-blue-400"
                                    }`}
                                >
                                    Month Wise APP Performance 
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setActiveTab(4)}
                                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                                        activeTab === 4
                                            ? "bg-white text-blue-600 font-bold"
                                            : "bg-blue-500 text-white hover:bg-blue-400"
                                    }`}
                                >
                                    Month Wise APP Success 
                                </button>
                            </div>
                        </div>

                        {/* ACTIVE TAB CONTENT */}
                        <div className="p-">{renderTabContent()}</div>
                    </div>
                </div>
            </div>

            {/* FOOTER */}
            <Footer />
        </div>
    );
};

export default AppPerformanceMaster;