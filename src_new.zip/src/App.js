import logo from './logo.svg';
import {react, useEffect} from 'react';
import './App.css';
import {Routes, Route} from 'react-router-dom';
import Login from './Backend/Login.jsx';
import Dashboard from './Dashbord/dashboard.jsx';
import SessionProvider from './context/sessionContext';
import {BrowserRouter} from 'react-router-dom';
import Targetsales from './targetsales/page.jsx';
import Footer from './components/footer.jsx';
import ProtectedRoute from './ProtectedRoute.jsx';
import SectorReport from './targetsales/SectorReport.jsx';
import UplodeTargetSale from './targetsales/UplodeTargetSale.jsx';
import AppPerformance from './targetsales/AppPerformance.jsx';
import CustomerAPPsignedvsSales from './targetsales/CustomerAPPsignedvsSales.jsx';

import {AgGridReact} from 'ag-grid-react';
import {ModuleRegistry, AllCommunityModule} from 'ag-grid-community';

import {ExcelExportModule} from 'ag-grid-enterprise';
import 'ag-grid-enterprise';
import Master from './targetsales/Grademaster.jsx';
import ParentTypeMaster from './targetsales/ParentTypeMaster.jsx';
import ZoneMaster from './targetsales/Zonemaster.jsx';
import TypeMaster from './targetsales/Typemaster.jsx';
import RscMaster from './targetsales/Rscmaster.jsx';
import SegmentMaster from './targetsales/SegmentMaster.jsx';
import AppCreationMaster from './targetsales/AppCreationMaster.jsx';
import ContactUpdate from './targetsales/ContactUpdate.jsx';
import DopwMaster from './targetsales/DopwMaster.jsx';

import AppPerformaceStatus from './targetsales/AppPerformanceStatus.jsx';

ModuleRegistry.registerModules([ExcelExportModule]);

ModuleRegistry.registerModules([AllCommunityModule]);
function App() {
  useEffect(() => {
    const handleUnload = () => {
      sessionStorage.clear(); // clear session on browser/tab close
    };

    // window.addEventListener("beforeunload", handleUnload);

    return () => {
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, []);
  return (
    <SessionProvider>
      <BrowserRouter basename={'/SalesAnalytics'}>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/targetsales/page"
            element={
              <ProtectedRoute>
                <Targetsales />
              </ProtectedRoute>
            }
          />
          <Route
            path="/SectorReport"
            element={
              <ProtectedRoute>
                <SectorReport />
              </ProtectedRoute>
            }
          />
          <Route
            path="/UplodeTargetSales"
            element={
              <ProtectedRoute>
                <UplodeTargetSale />
              </ProtectedRoute>
            }
          />
          <Route
            path="/AppPerformance"
            element={
              <ProtectedRoute>
                <AppPerformance />
              </ProtectedRoute>
            }
          />
          {/* <Route path="/CustomerAPP" element={<ProtectedRoute><CustomerAPPsignedvsSales /></ProtectedRoute>} /> */}
          <Route
            path="/CustomerAPP"
            element={
              <ProtectedRoute>
                <CustomerAPPsignedvsSales />
              </ProtectedRoute>
            }
          />
          <Route
            path="/GradeMaster"
            element={
              <ProtectedRoute>
                <Master />
              </ProtectedRoute>
            }
          />
             <Route
            path="/AppCreationMaster"
            element={
              <ProtectedRoute>
                <AppCreationMaster />
              </ProtectedRoute>
            }
          />
          <Route
            path="/ParentTypeMaster"
            element={
              <ProtectedRoute>
                <ParentTypeMaster />
              </ProtectedRoute>
            }
          />
          <Route
            path="/ZoneMaster"
            element={
              <ProtectedRoute>
                <ZoneMaster />
              </ProtectedRoute>
            }
          />
          <Route
            path="/TypeMaster"
            element={
              <ProtectedRoute>
                <TypeMaster />
              </ProtectedRoute>
            }
          />

          <Route
            path="/DopwMaster"
            element={
              <ProtectedRoute>
                <DopwMaster />
              </ProtectedRoute>
            }
          />
          
           <Route
            path="/ContactUpdate"
            element={
              <ProtectedRoute>
                <ContactUpdate />
              </ProtectedRoute>
            }
          />

           <Route
            path="/Appperformancestatus"
            element={
              <ProtectedRoute>
                <AppPerformaceStatus />
              </ProtectedRoute>
            }
          />
          <Route
            path="/RscMaster"
            element={
              <ProtectedRoute>
                <RscMaster />
              </ProtectedRoute>
            }
          />
          <Route
            path="/SegmentMaster"
            element={
              <ProtectedRoute>
                <SegmentMaster />
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </SessionProvider>
  );
}

export default App;
