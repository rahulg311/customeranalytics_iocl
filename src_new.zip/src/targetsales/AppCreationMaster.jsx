
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";
import Select, { components } from "react-select";
import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";

// Base API URL
const API_BASE_URL =
    "http://10.14.84.54/Customeranalytics_API/api/Master";

const AppCreationMaster = () => {


    const [name, setName] = useState("");
    const [year, setYear] = useState("");
    const [status, setStatus] = useState("A");

    const [categoryOptions, setCategoryOptions] = useState([]);
    const [categoryCode, setCategoryCode] = useState([]);

    // const currentYear = new Date().getFullYear();

    // const formattedYear = `${currentYear}${String(
    //     currentYear + 1
    // ).slice(-2)}`;

    // const formattedYear2 = `${String(
    //     currentYear + 1
    // )}${String(currentYear + 2).slice(-2)}`;


    const today = new Date();
const currentYear = today.getFullYear();
const month = today.getMonth(); // Jan = 0, Apr = 3

// Financial year April se start hota hai
const financialYearStart =
    month >= 3 ? currentYear : currentYear - 1;

// Current Financial Year
const currentFinancialYear = `${financialYearStart}${String(
    financialYearStart + 1
).slice(-2)}`;

// Next Financial Year
const nextFinancialYear = `${financialYearStart + 1}${String(
    financialYearStart + 2
).slice(-2)}`;

const typeOptions = [
    {
        key: currentFinancialYear,
        value: currentFinancialYear,
    },
    {
        key: nextFinancialYear,
        value: nextFinancialYear,
    },
];



    const [showModal, setShowModal] = useState(false);
    const [selectedParents, setSelectedParents] = useState([]);

    const [loading, setLoading] = useState(false);
    const [gridLoading, setGridLoading] = useState(false);
    const [rowData, setRowData] = useState([]);
    const [editIndex, setEditIndex] = useState(null);

    const fetchParentTargets = useCallback(async () => {
        setGridLoading(true);

        try {
            const response = await fetch(
                `${API_BASE_URL}/GetAllAppMaster`
            );

            if (response.ok) {
                const data = await response.json();

                console.log("Fetched APP Master:", data);

                setRowData(
                    Array.isArray(data)
                        ? data
                        : data.data || []
                );
            } else {
                console.error(
                    "Failed to fetch APP Master. Status:",
                    response.status
                );

                toast.error("Failed to load list data.");
            }
        } catch (error) {
            console.error("GET API Error:", error);

            toast.error(
                "Network error while fetching APP Master list."
            );
        } finally {
            setGridLoading(false);
        }
    }, []);


    const Categoryapicall = async () => {
        try {
            const response = await fetch(
                `${API_BASE_URL}/GetAllParentTargetMaster`
            );

            if (response.ok) {
                const data = await response.json();

                const options = data.map((item) => ({
                    value: item.parentCode.toString(),
                    label: `${item.parentDescription} - (${item.parentCode})`,
                }));

                setCategoryOptions(options);
            } else {
                console.error(
                    "Failed to fetch Parent Targets. Status:",
                    response.status
                );

                toast.error("Failed to load parent list data.");
            }
        } catch (error) {
            console.error("Category API Error:", error);

            toast.error(
                "Network error while fetching Parent Target list."
            );
        }
    };

   
    useEffect(() => {
        fetchParentTargets();
        Categoryapicall();
    }, [fetchParentTargets]);


    const CustomOption = (props) => {
        return (
            <components.Option {...props}>
                <div className="flex items-center gap-2">
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                        className="cursor-pointer"
                    />
                    <span>{props.label}</span>
                </div>
            </components.Option>
        );
    };


    const handleCategoryChange = (selectedOptions) => {
        const values = selectedOptions
            ? selectedOptions.map((item) => item.value)
            : [];

        setCategoryCode(values);
    };


    const handleSubmit = async (e) => {
        e.preventDefault();

        const payload = {
            appCode:
                editIndex !== null
                    ? rowData[editIndex]?.appCode
                    : "",

            appDescription: name,

            appYear: year,

            activeFlag: status,

            createdBy:
                editIndex !== null
                    ? ""
                    : localStorage.getItem("username"),

            updatedBy:
                editIndex !== null
                    ? localStorage.getItem("username")
                    : "",

            parentCodes: categoryCode,
        };

        console.log("Payload:", payload);

        const isUpdating = editIndex !== null;

        const apiUrl = isUpdating
            ? `${API_BASE_URL}/UpdateAppMaster`
            : `${API_BASE_URL}/AddAppMaster`;

        setLoading(true);

        try {
            const response = await fetch(apiUrl, {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                },

                body: JSON.stringify(payload),
            });

            if (response.ok) {
                toast.success(
                    isUpdating
                        ? "APP Master Updated Successfully!"
                        : "APP Master Added Successfully!"
                );

                handleReset();

                await fetchParentTargets();
            } else {
                toast.warning(
                    `Failed to ${
                        isUpdating ? "update" : "save"
                    } record. Status: ${response.status}`
                );
            }
        } catch (error) {
            console.error("Submit API Error:", error);

            toast.error("Network or API Server Error!");
        } finally {
            setLoading(false);
        }
    };


    const handleEdit = (data, index) => {
        console.log("Edit Data:", data);

        setName(data.appDescription || "");

        setStatus(
            data.activeFlag?.trim() || "A"
        );

        setYear(data.appYear || "");

        // =========================
        // Existing Parent Codes
        // =========================
        const selectedParentCodes =
            data.parents?.map((parent) =>
                parent.parentCode.toString()
            ) || [];

        console.log(
            "Selected Parent Codes:",
            selectedParentCodes
        );

        setCategoryCode(selectedParentCodes);

        setEditIndex(index);

        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    };


    const handleReset = () => {
        setName("");
        setYear("");
        setCategoryCode([]);
        setStatus("A");
        setEditIndex(null);
    };

    const selectedCategoryOptions = useMemo(() => {
        return categoryOptions.filter((item) =>
            categoryCode.includes(item.value)
        );
    }, [categoryOptions, categoryCode]);

    // =========================
    // AG Grid Columns
    // =========================
    const columnDefs = useMemo(
        () => [
            {
                headerName: "App Name",

                valueGetter: (params) =>
                    params.data?.appDescription || "",

                flex: 1,

                sortable: true,

                filter: true,
            },

            {
                headerName: "App Year",

                valueGetter: (params) =>
                    params.data?.appYear || "",

                flex: 1,

                sortable: true,

                filter: true,
            },

            {
                headerName: "Status",

                width: 120,

                cellRenderer: (params) => (
                    <div className="flex items-center h-full">
                        <span className="bg-blue-600 text-white px-3 py-1 rounded text-xs">
                            {params.data?.activeFlag?.trim() ===
                            "A"
                                ? "Active"
                                : "Inactive"}
                        </span>
                    </div>
                ),
            },

            {
                headerName: "Action",

                width: 280,

                cellRenderer: (params) => (
                    <div className="flex items-center h-full gap-2">

                        <button
                            type="button"
                            onClick={() => {
                                setSelectedParents(
                                    params.data.parents || []
                                );

                                setShowModal(true);
                            }}
                            className="bg-green-600 text-white px-3 py-1 rounded text-xs hover:bg-green-700"
                        >
                            View Linked Parent
                        </button>

                        <button
                            type="button"
                            onClick={() =>
                                handleEdit(
                                    params.data,
                                    params.node?.rowIndex
                                )
                            }
                            className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
                        >
                            Edit
                        </button>

                    </div>
                ),
            },
        ],
        []
    );


    return (
        <div className="min-h-screen flex flex-col bg-gray-100">

            <Header headerName="Parent Type Master" />

            <div className="flex-1 p-6">

                <div className="mx-auto">

              
                    <div className="bg-white rounded-lg shadow-lg">

                        <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">

                            <h2 className="text-xl font-semibold">
                                {editIndex !== null
                                    ? "Update APP Creation Master"
                                    : "Add APP Creation Master"}
                            </h2>

                        </div>

                        <form
                            onSubmit={handleSubmit}
                            className="p-6"
                        >

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">

                              
                                <div>

                                    <label className="block mb-2 font-medium text-gray-700">
                                        Name{" "}
                                        <span className="text-red-500">
                                            *
                                        </span>
                                    </label>

                                    <input
                                        type="text"
                                        value={name}
                                        disabled={
                                            editIndex !== null
                                        }
                                        onChange={(e) =>
                                            setName(
                                                e.target.value
                                            )
                                        }
                                        placeholder="Enter Name"
                                        className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none ${
                                            editIndex !== null
                                                ? "bg-gray-100 cursor-not-allowed"
                                                : ""
                                        }`}
                                        required
                                    />

                                </div>

               
                                <div>

                                    <label className="block mb-2 font-medium text-gray-700">
                                        Year{" "}
                                        <span className="text-red-500">
                                            *
                                        </span>
                                    </label>

                                    <select
                                        value={year}
                                        onChange={(e) =>
                                            setYear(
                                                e.target.value
                                            )
                                        }
                                        className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                        required
                                    >

                                        <option value="">
                                            Select Year
                                        </option>

                                        {typeOptions.map(
                                            (item) => (
                                                <option
                                                    key={
                                                        item.key
                                                    }
                                                    value={
                                                        item.key
                                                    }
                                                >
                                                    {item.value}
                                                </option>
                                            )
                                        )}

                                    </select>

                                </div>

                      
                                <div>

                                    <label className="block mb-2 font-medium text-gray-700">
                                  Category Code
                                        <span className="text-red-500">
                                            *
                                        </span>
                                    </label>

                                    <Select
                                        isMulti
                                        isSearchable
                                        isClearable
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}

                                        options={categoryOptions}

                                        value={
                                            selectedCategoryOptions
                                        }

                                        onChange={
                                            handleCategoryChange
                                        }

                                        components={{
                                            Option: CustomOption,
                                        }}

                                        placeholder="Select Parent"

                                        noOptionsMessage={() =>
                                            "No Parent Found"
                                        }

                                        className="w-full"

                                        styles={{
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),

                                            menuPortal: (
                                                base
                                            ) => ({
                                                ...base,
                                                zIndex: 9999,
                                            }),
                                        }}

                                        menuPortalTarget={
                                            document.body
                                        }
                                    />

                                </div>

                                <div>

                                    <label className="block mb-2 font-medium text-gray-700">
                                        Status{" "}
                                        <span className="text-red-500">
                                            *
                                        </span>
                                    </label>

                                    <select
                                        value={status}
                                        onChange={(e) =>
                                            setStatus(
                                                e.target.value
                                            )
                                        }
                                        className="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                        required
                                    >

                                        <option
                                            value="A"
                                        >
                                            Active
                                        </option>

                                        <option
                                            value="D"
                                        >
                                            Inactive
                                        </option>

                                    </select>

                                </div>

                            </div>

                            <div className="flex justify-end gap-3 mt-6">

                                <button
                                    type="button"
                                    onClick={handleReset}
                                    className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-md"
                                    disabled={loading}
                                >
                                    Reset
                                </button>

                                <button
                                    type="submit"
                                    disabled={loading}
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md disabled:bg-blue-300"
                                >
                                    {loading
                                        ? "Submitting..."
                                        : editIndex !== null
                                        ? "Update"
                                        : "Save"}
                                </button>

                            </div>

                        </form>

                    </div>

    
                    <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-5 mt-6">

                        <div className="flex justify-between items-center mb-4">

                            <h2 className="text-lg font-semibold text-gray-700">
                                APP Master List
                            </h2>

                            {gridLoading && (
                                <span className="text-sm text-blue-600 font-medium">
                                    Loading Grid Data...
                                </span>
                            )}

                        </div>

                        <div
                            className="ag-theme-alpine"
                            style={{
                                height: "450px",
                                width: "100%",
                            }}
                        >

                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                pagination={true}
                                paginationPageSize={10}
                            />

                        </div>

                    </div>

                </div>

            </div>

            {showModal && (

                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">

                    <div className="bg-white rounded-lg shadow-xl w-[500px] max-w-[90%]">

                        {/* Header */}
                        <div className="flex justify-between items-center border-b px-5 py-3">

                            <h2 className="text-lg font-semibold">
                                Linked Parent Targets
                            </h2>

                            <button
                                onClick={() =>
                                    setShowModal(false)
                                }
                                className="text-gray-500 hover:text-red-500 text-xl"
                            >
                                ✕
                            </button>

                        </div>

               
                        <div className="p-5">

                            {selectedParents.length > 0 ? (

                                <div className="flex flex-wrap gap-3">

                                    {selectedParents.map(
                                        (parent) => (

                                            <button
                                                key={
                                                    parent.parentCode
                                                }
                                                className="px-4 py-2 rounded-full bg-blue-100 text-blue-700 border border-blue-300 hover:bg-blue-600 hover:text-white transition"
                                            >
                                                {
                                                    parent.parentDescription
                                                }
                                            </button>

                                        )
                                    )}

                                </div>

                            ) : (

                                <p className="text-gray-500 text-center">
                                    No Parent Linked
                                </p>

                            )}

                        </div>

                        {/* Footer */}
                        <div className="flex justify-end border-t px-5 py-3">

                            <button
                                onClick={() =>
                                    setShowModal(false)
                                }
                                className="bg-red-600 text-white px-5 py-2 rounded hover:bg-red-700"
                            >
                                Close
                            </button>

                        </div>

                    </div>

                </div>

            )}

            <Footer />

            <ToastContainer
                position="top-right"
                autoClose={3000}
            />

        </div>
    );
};

export default AppCreationMaster;

