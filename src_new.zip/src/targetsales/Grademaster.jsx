import React, { useState, useEffect, useMemo, useCallback } from "react";
import { AgGridReact } from "ag-grid-react";
import Header from "../components/header";
import Footer from "../components/footer";
import { ToastContainer, toast } from "react-toastify";
import { hostUrl } from "../utils/constant";

const GradeMaster = () => {
  // Input Fields
  const [gradeCode, setGradeCode] = useState("");
  const [gradeDesignation, setGradeDesignation] = useState("");
  const [gradeShortName, setGradeShortName] = useState("");
  const [gradeGroup, setGradeGroup] = useState("");

  // Dropdown Fields State
  const [qualityCode, setQualityCode] = useState("");
  const [categoryCode, setCategoryCode] = useState("");
  const [typeCode, setTypeCode] = useState("");
  const [parentCode, setParentCode] = useState("");

  // Dynamic Options State for Dropdowns
  const [qualityOptions, setQualityOptions] = useState([]);
  const [typeOptions, setTypeOptions] = useState([]);
  const [parentOptions, setParentOptions] = useState([]);
   const [categoryOptions, setcategoryOptions] = useState([]);

  // Static Category Options
  // const categoryOptions = [
  //   { id: "", label: "Select Category Code" },
  //   { id: "CAT01", label: "Category 01" },
  //   { id: "CAT02", label: "Category 02" },
  // ];

  // UI & Loading State
  const [loading, setLoading] = useState(false);
  const [gridLoading, setGridLoading] = useState(false);

  // Grid State
  const [rowData, setRowData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // 1. Fetch Dropdown Options APIs
  const fetchDropdownData = useCallback(async () => {
    try {
      const [qualityRes, typeRes, parentRes,categoryres] = await Promise.all([
        fetch(`${hostUrl}/Master/GetAllQualityMaster`),
        fetch(`${hostUrl}/Master/GetAllTypeMaster`),
        fetch(`${hostUrl}/Master/GetAllParentTargetMaster`),
         fetch(`${hostUrl}/Master/GetAllCategoryMaster`),
      ]);

      if (qualityRes.ok) {
        const data = await qualityRes.json();
        setQualityOptions(
          data.map((item) => ({
            id: item.qualityCode,
            label: `${item.qualityName} (${item.qualityCode})`,
          }))
        );
      }

      if (typeRes.ok) {
        const data = await typeRes.json();
        setTypeOptions(
          data.map((item) => ({
            id: item.typeCode,
            label: `${item.typeName} (${item.typeDescription})`,
          }))
        );
      }

      if (parentRes.ok) {
        const data = await parentRes.json();
        setParentOptions(
          data.map((item) => ({
            id: item.parentCode,
            label: `${item.parentDescription} (${item.parentCode})`,
          }))
        );
      }
       if (categoryres.ok) {
        const data = await categoryres.json();
        setcategoryOptions(
          data.map((item) => ({
            id: item.category_Code,
            label: item.category_Desc,
          }))
        );
      }

      
    } catch (error) {
      console.error("Error fetching dropdown options:", error);
    }
  }, []);

  // 2. Fetch Grade Master Grid Data
  const fetchGradeMasters = useCallback(async () => {
    setGridLoading(true);
    try {
      const response = await fetch(
        `${hostUrl}/Master/GetAllGradeMaster`
      );

      if (response.ok) {
        const data = await response.json();
        setRowData(Array.isArray(data) ? data : data.data || []);
      } else {
        console.error("Failed to fetch Grade Master list. Status:", response.status);
      }
    } catch (error) {
      console.error("GET API Error:", error);
    } finally {
      setGridLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDropdownData();
    fetchGradeMasters();
  }, [fetchDropdownData, fetchGradeMasters]);

  // 3. Save / Update Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      gradeCode,
      gradeDesignation,
      gradeShortName,
      qualityCode,
      categoryCode,
      typeCode,
      gradeGroup,
      parentCode,
    };

    const isUpdating = editIndex !== null;
    const apiUrl = isUpdating
      ? "${hostUrl}/Master/UpdateGradeMaster"
      : "${hostUrl}/Master/AddGradeMaster";

    setLoading(true);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(isUpdating ? "Record Updated Successfully!" : "Record Saved Successfully!");
        handleReset();
        fetchGradeMasters();
      } else {
        toast.warning(`Failed to ${isUpdating ? "update" : "save"} data. Status: ` + response.status);
      }
    } catch (error) {
      toast.warning("Network or API Server Error!");
      console.error("API Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data, index) => {
    setGradeCode(data.gradeCode || "");
    setGradeDesignation(data.gradeDesignation || "");
    setGradeShortName(data.gradeShortName || "");
    setQualityCode(data.qualityCode || "");
    setCategoryCode(data.categoryCode || "");
    setTypeCode(data.typeCode || "");
    setGradeGroup(data.gradeGroup || "");
    setParentCode(data.parentCode || "");

    setEditIndex(index);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    setGradeCode("");
    setGradeDesignation("");
    setGradeShortName("");
    setQualityCode("");
    setCategoryCode("");
    setTypeCode("");
    setGradeGroup("");
    setParentCode("");
    setEditIndex(null);
  };

  const columnDefs = useMemo(
    () => [
      { headerName: "Grade Code", field: "gradeCode", flex: 1, sortable: true, filter: true },
      { headerName: "Designation", field: "gradeDesignation", flex: 1, sortable: true, filter: true },
      { headerName: "Short Name", field: "gradeShortName", flex: 1, sortable: true, filter: true },
      { headerName: "Quality Code", field: "qualityCode", flex: 1, sortable: true, filter: true },
      { headerName: "Category Code", field: "categoryCode", flex: 1, sortable: true, filter: true },
      { headerName: "Type Code", field: "typeCode", flex: 1, sortable: true, filter: true },
      { headerName: "Grade Group", field: "gradeGroup", flex: 1, sortable: true, filter: true },
      { headerName: "Parent Code", field: "parentCode", flex: 1, sortable: true, filter: true },
      {
        headerName: "Action",
        width: 120,
        cellRenderer: (params) => (
          <div className="flex gap-2 mt-2">
            <button
              type="button"
              onClick={() => handleEdit(params.data, params.node.rowIndex)}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
            >
              Edit
            </button>
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header headerName="Grade Master" />

      <div className="flex-1 p-6">
        <div className="mx-auto">
          {/* Form Section */}
          <div className="bg-white rounded-lg shadow-lg">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
              <h2 className="text-xl font-semibold">
                {editIndex !== null ? "Edit Grade Master" : "Create Grade Master"}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                
                {/* Grade Code (Disabled in edit mode) */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={gradeCode}
                    disabled={editIndex !== null}
                    onChange={(e) => setGradeCode(e.target.value)}
                    placeholder="Enter Grade Code"
                    required
                    className={`w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      editIndex !== null ? "bg-gray-100 cursor-not-allowed" : ""
                    }`}
                  />
                </div>

                {/* Grade Designation */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade Designation <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={gradeDesignation}
                    onChange={(e) => setGradeDesignation(e.target.value)}
                    placeholder="Enter Grade Designation"
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

          
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade Short Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={gradeShortName}
                    onChange={(e) => setGradeShortName(e.target.value)}
                    placeholder="Enter Grade Short Name"
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

          
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Quality Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={qualityCode}
                    onChange={(e) => setQualityCode(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Quality Code</option>
                    {qualityOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

       
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Category Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={categoryCode}
                    onChange={(e) => setCategoryCode(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Category Code</option>
                    {categoryOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Type Code Dropdown */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Type Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={typeCode}
                    onChange={(e) => setTypeCode(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Type Code</option>
                    {typeOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Grade Group Input */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Grade Group <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={gradeGroup}
                    onChange={(e) => setGradeGroup(e.target.value)}
                    placeholder="Enter Grade Group"
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Parent Code Dropdown */}
                <div>
                  <label className="block mb-1 font-medium text-gray-700">
                    Parent Code <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={parentCode}
                    onChange={(e) => setParentCode(e.target.value)}
                    required
                    className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Parent Code</option>
                    {parentOptions.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={handleReset}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded transition-colors"
                  disabled={loading}
                >
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded transition-colors disabled:bg-blue-300"
                >
                  {loading ? "Submitting..." : editIndex !== null ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>

          {/* AG Grid Section */}
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-5 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-700">
                Grade Master List
              </h2>
              {gridLoading && (
                <span className="text-sm text-blue-600 font-medium">Loading Grid Data...</span>
              )}
            </div>
            
            <div
              className="ag-theme-alpine"
              style={{ height: "400px", width: "100%" }}
            >
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>

        </div>
      </div>

      <Footer />
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default GradeMaster;